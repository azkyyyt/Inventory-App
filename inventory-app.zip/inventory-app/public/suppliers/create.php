<?php
// public/suppliers/create.php
require_once __DIR__ . '/../../config/database.php';
require_once __DIR__ . '/../../helpers/auth.php';
require_once __DIR__ . '/../../helpers/escape.php';

requireRole('admin');
$pdo = getPDO();

$errors = [];
$name = '';
$contactName = '';
$phone = '';
$email = '';
$address = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name = trim($_POST['name'] ?? '');
    $contactName = trim($_POST['contact_name'] ?? '');
    $phone = trim($_POST['phone'] ?? '');
    $email = trim($_POST['email'] ?? '');
    $address = trim($_POST['address'] ?? '');

    if (empty($name)) {
        $errors[] = 'Nama supplier wajib diisi.';
    }

    if (empty($errors)) {
        $stmt = $pdo->prepare("
            INSERT INTO suppliers (name, contact_name, phone, email, address)
            VALUES (:name, :contact_name, :phone, :email, :address)
        ");
        $stmt->execute([
            'name' => $name,
            'contact_name' => $contactName,
            'phone' => $phone,
            'email' => $email,
            'address' => $address
        ]);

        $_SESSION['flash_success'] = 'Supplier "' . $name . '" berhasil ditambahkan.';
        header("Location: index.php");
        exit;
    }
}

$pageTitle = 'Tambah Supplier';
include __DIR__ . '/../../views/header.php';
?>

<div class="row justify-content-center">
    <div class="col-md-8 col-lg-6">
        <div class="card shadow-sm border-0">
            <div class="card-header bg-primary text-white py-3">
                <h5 class="mb-0 fw-bold"><i class="fa-solid fa-plus-circle me-2"></i>Tambah Supplier Baru</h5>
            </div>
            <div class="card-body p-4">
                <?php if (!empty($errors)): ?>
                    <div class="alert alert-danger shadow-sm">
                        <ul class="mb-0 ps-3">
                            <?php foreach ($errors as $err): ?>
                                <li><?= e($err) ?></li>
                            <?php endforeach; ?>
                        </ul>
                    </div>
                <?php endif; ?>

                <form method="POST" action="create.php">
                    <div class="mb-3">
                        <label for="name" class="form-label fw-semibold">Nama Perusahaan / Supplier <span class="text-danger">*</span></label>
                        <input type="text" class="form-control" id="name" name="name" value="<?= e($name) ?>" required placeholder="Contoh: PT Megah Tech">
                    </div>
                    <div class="mb-3">
                        <label for="contact_name" class="form-label fw-semibold">Nama Kontak (PIC)</label>
                        <input type="text" class="form-control" id="contact_name" name="contact_name" value="<?= e($contactName) ?>" placeholder="Contoh: Budi Santoso">
                    </div>
                    <div class="row">
                        <div class="col-md-6 mb-3">
                            <label for="phone" class="form-label fw-semibold">No. Telepon</label>
                            <input type="text" class="form-control" id="phone" name="phone" value="<?= e($phone) ?>" placeholder="Contoh: 021-5551234">
                        </div>
                        <div class="col-md-6 mb-3">
                            <label for="email" class="form-label fw-semibold">Email</label>
                            <input type="email" class="form-control" id="email" name="email" value="<?= e($email) ?>" placeholder="Contoh: info@megah.com">
                        </div>
                    </div>
                    <div class="mb-3">
                        <label for="address" class="form-label fw-semibold">Alamat</label>
                        <textarea class="form-control" id="address" name="address" rows="3"><?= e($address) ?></textarea>
                    </div>
                    <div class="d-flex justify-content-between align-items-center mt-4 pt-3 border-top">
                        <a href="index.php" class="btn btn-outline-secondary"><i class="fa-solid fa-arrow-left me-1"></i> Batal</a>
                        <button type="submit" class="btn btn-primary fw-bold"><i class="fa-solid fa-floppy-disk me-1"></i> Simpan Supplier</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>

<?php include __DIR__ . '/../../views/footer.php'; ?>
