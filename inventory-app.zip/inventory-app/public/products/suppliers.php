<?php
// public/products/suppliers.php
// Managing Many-to-Many Relationship between Products and Suppliers via Junction Table (Slide 5, 8, 32)

require_once __DIR__ . '/../../config/database.php';
require_once __DIR__ . '/../../helpers/auth.php';
require_once __DIR__ . '/../../helpers/validation.php';
require_once __DIR__ . '/../../helpers/escape.php';

requireAuth();
$pdo = getPDO();
$user = currentUser();

$productId = filter_input(INPUT_GET, 'id', FILTER_VALIDATE_INT);
if (!$productId) {
    header("Location: index.php");
    exit;
}

$stmtProduct = $pdo->prepare("
    SELECT p.*, c.name AS category_name 
    FROM products p 
    JOIN categories c ON c.id = p.category_id 
    WHERE p.id = :id
");
$stmtProduct->execute(['id' => $productId]);
$product = $stmtProduct->fetch();

if (!$product) {
    $_SESSION['flash_error'] = 'Produk tidak ditemukan.';
    header("Location: index.php");
    exit;
}

$errors = [];

// Handle Form Submission (Add or Delete Supplier Association)
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if ($user['role'] !== 'admin') {
        $_SESSION['flash_error'] = 'Hanya Admin yang dapat mengubah relasi supplier.';
    } else {
        $action = $_POST['action'] ?? '';
        if ($action === 'add') {
            $supplierId = filter_input(INPUT_POST, 'supplier_id', FILTER_VALIDATE_INT);
            $supplierPriceVal = trim($_POST['supplier_price'] ?? '');

            if (!$supplierId || $supplierId <= 0) {
                $errors[] = 'Pilih supplier yang valid.';
            }

            $validPrice = validateNonNegativeFloat($supplierPriceVal);
            if ($supplierPriceVal !== '' && $validPrice === false) {
                $errors[] = 'Harga dari supplier tidak boleh negatif.';
            }

            if (empty($errors)) {
                $stmtAttach = $pdo->prepare("
                    INSERT INTO product_suppliers (product_id, supplier_id, supplier_price)
                    VALUES (:product_id, :supplier_id, :supplier_price)
                    ON DUPLICATE KEY UPDATE supplier_price = VALUES(supplier_price)
                ");
                $stmtAttach->execute([
                    'product_id' => $productId,
                    'supplier_id' => $supplierId,
                    'supplier_price' => $validPrice !== false ? $validPrice : null
                ]);
                $_SESSION['flash_success'] = 'Supplier berhasil dihubungkan ke produk.';
                header("Location: suppliers.php?id=" . $productId);
                exit;
            }
        } elseif ($action === 'delete') {
            $supplierId = filter_input(INPUT_POST, 'supplier_id', FILTER_VALIDATE_INT);
            if ($supplierId) {
                $stmtDetach = $pdo->prepare("DELETE FROM product_suppliers WHERE product_id = :product_id AND supplier_id = :supplier_id");
                $stmtDetach->execute(['product_id' => $productId, 'supplier_id' => $supplierId]);
                $_SESSION['flash_success'] = 'Relasi supplier berhasil dihapus.';
                header("Location: suppliers.php?id=" . $productId);
                exit;
            }
        }
    }
}

// Fetch attached suppliers for this product
$stmtAttached = $pdo->prepare("
    SELECT ps.supplier_id, ps.supplier_price, s.name AS supplier_name, s.contact_name, s.phone, s.email
    FROM product_suppliers ps
    JOIN suppliers s ON s.id = ps.supplier_id
    WHERE ps.product_id = :product_id
    ORDER BY s.name ASC
");
$stmtAttached->execute(['product_id' => $productId]);
$attachedSuppliers = $stmtAttached->fetchAll();

// Fetch all available suppliers for dropdown
$stmtAllSuppliers = $pdo->query("SELECT id, name FROM suppliers ORDER BY name ASC");
$allSuppliers = $stmtAllSuppliers->fetchAll();

$pageTitle = 'Supplier Produk - ' . $product['name'];
include __DIR__ . '/../../views/header.php';
?>

<div class="mb-3">
    <a href="index.php" class="btn btn-outline-secondary btn-sm"><i class="fa-solid fa-arrow-left me-1"></i> Kembali ke Daftar Produk</a>
</div>

<div class="card shadow-sm border-0 mb-4">
    <div class="card-body bg-light">
        <div class="row align-items-center">
            <div class="col-md-8">
                <span class="badge bg-secondary mb-1"><?= e($product['category_name']) ?></span>
                <h3 class="fw-bold mb-1"><?= e($product['name']) ?></h3>
                <p class="text-muted small mb-0">SKU: <code><?= e($product['sku']) ?></code> | Harga Jual: <strong>Rp <?= number_format($product['price'], 0, ',', '.') ?></strong> | Stok: <strong><?= $product['stock'] ?> unit</strong></p>
            </div>
            <div class="col-md-4 text-md-end mt-2 mt-md-0">
                <span class="badge bg-info p-2 fs-6"><i class="fa-solid fa-link me-1"></i> Relasi Many-to-Many</span>
            </div>
        </div>
    </div>
</div>

<?php if (!empty($errors)): ?>
    <div class="alert alert-danger shadow-sm">
        <ul class="mb-0 ps-3">
            <?php foreach ($errors as $err): ?>
                <li><?= e($err) ?></li>
            <?php endforeach; ?>
        </ul>
    </div>
<?php endif; ?>

<div class="row">
    <!-- List Supplier Terhubung -->
    <div class="col-md-7 mb-4">
        <div class="card shadow-sm border-0">
            <div class="card-header bg-dark text-white py-3 d-flex justify-content-between align-items-center">
                <h5 class="mb-0 fw-bold"><i class="fa-solid fa-truck-field me-2"></i>Daftar Supplier Produk Ini</h5>
                <span class="badge bg-primary"><?= count($attachedSuppliers) ?> Supplier</span>
            </div>
            <div class="card-body p-0">
                <div class="table-responsive">
                    <table class="table table-hover align-middle mb-0">
                        <thead class="table-light">
                            <tr>
                                <th class="ps-3">Nama Supplier</th>
                                <th>Kontak / Telp</th>
                                <th class="text-end">Harga Pasokan (Beli)</th>
                                <?php if ($user['role'] === 'admin'): ?><th class="text-center">Aksi</th><?php endif; ?>
                            </tr>
                        </thead>
                        <tbody>
                            <?php if (count($attachedSuppliers) === 0): ?>
                            <tr><td colspan="4" class="text-center py-4 text-muted">Belum ada supplier yang dihubungkan ke produk ini.</td></tr>
                            <?php else: ?>
                            <?php foreach ($attachedSuppliers as $sup): ?>
                            <tr>
                                <td class="ps-3">
                                    <strong><?= e($sup['supplier_name']) ?></strong>
                                </td>
                                <td class="small">
                                    <?= e($sup['contact_name'] ?: '-') ?><br>
                                    <span class="text-muted"><?= e($sup['phone'] ?: '-') ?></span>
                                </td>
                                <td class="text-end">
                                    <?= $sup['supplier_price'] !== null ? 'Rp ' . number_format($sup['supplier_price'], 0, ',', '.') : '-' ?>
                                </td>
                                <?php if ($user['role'] === 'admin'): ?>
                                <td class="text-center">
                                    <form method="POST" action="suppliers.php?id=<?= $productId ?>" onsubmit="return confirm('Hapus relasi supplier ini?');">
                                        <input type="hidden" name="action" value="delete">
                                        <input type="hidden" name="supplier_id" value="<?= $sup['supplier_id'] ?>">
                                        <button type="submit" class="btn btn-sm btn-outline-danger py-0 px-2">
                                            <i class="fa-solid fa-unlink"></i> Lepas
                                        </button>
                                    </form>
                                </td>
                                <?php endif; ?>
                            </tr>
                            <?php endforeach; ?>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>

    <!-- Form Tambah/Hubungkan Supplier (Admin Only) -->
    <?php if ($user['role'] === 'admin'): ?>
    <div class="col-md-5 mb-4">
        <div class="card shadow-sm border-0">
            <div class="card-header bg-primary text-white py-3">
                <h5 class="mb-0 fw-bold"><i class="fa-solid fa-plus me-2"></i>Hubungkan Supplier Baru</h5>
            </div>
            <div class="card-body p-4">
                <form method="POST" action="suppliers.php?id=<?= $productId ?>">
                    <input type="hidden" name="action" value="add">

                    <div class="mb-3">
                        <label for="supplier_id" class="form-label fw-semibold">Pilih Supplier <span class="text-danger">*</span></label>
                        <select class="form-select" id="supplier_id" name="supplier_id" required>
                            <option value="">-- Pilih Supplier --</option>
                            <?php foreach ($allSuppliers as $s): ?>
                                <option value="<?= $s['id'] ?>"><?= e($s['name']) ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>

                    <div class="mb-3">
                        <label for="supplier_price" class="form-label fw-semibold">Harga Beli dari Supplier (Rp)</label>
                        <input type="number" step="0.01" class="form-control" id="supplier_price" name="supplier_price" placeholder="Contoh: 350000">
                        <div class="form-text">Harga pasokan dari supplier ini (opsional).</div>
                    </div>

                    <button type="submit" class="btn btn-primary w-100 fw-bold">
                        <i class="fa-solid fa-link me-1"></i> Simpan Relasi (Junction Table)
                    </button>
                </form>
            </div>
        </div>
    </div>
    <?php endif; ?>
</div>

<?php include __DIR__ . '/../../views/footer.php'; ?>
