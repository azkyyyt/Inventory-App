<?php
// public/suppliers/index.php
require_once __DIR__ . '/../../config/database.php';
require_once __DIR__ . '/../../helpers/auth.php';
require_once __DIR__ . '/../../helpers/escape.php';

requireAuth();
$pdo = getPDO();
$user = currentUser();

$stmt = $pdo->query("
    SELECT s.*, COUNT(ps.product_id) AS total_supplied_products
    FROM suppliers s
    LEFT JOIN product_suppliers ps ON ps.supplier_id = s.id
    GROUP BY s.id, s.name, s.contact_name, s.phone, s.email, s.address, s.created_at
    ORDER BY s.name ASC
");
$suppliers = $stmt->fetchAll();

$pageTitle = 'Kelola Supplier';
include __DIR__ . '/../../views/header.php';
?>

<div class="d-flex justify-content-between align-items-center mb-3">
    <div>
        <h2 class="fw-bold mb-0">Kelola Supplier</h2>
        <p class="text-muted small mb-0">Master data pemasok produk toko</p>
    </div>
    <?php if ($user['role'] === 'admin'): ?>
    <a href="create.php" class="btn btn-primary btn-sm">
        <i class="fa-solid fa-plus me-1"></i> Tambah Supplier
    </a>
    <?php endif; ?>
</div>

<div class="card shadow-sm border-0 mb-4">
    <div class="card-body p-0">
        <div class="table-responsive">
            <table class="table table-hover align-middle mb-0">
                <thead class="table-dark">
                    <tr>
                        <th class="ps-3">Nama Supplier</th>
                        <th>Kontak PIC</th>
                        <th>Telepon &amp; Email</th>
                        <th>Alamat</th>
                        <th class="text-center">Produk Disuplai</th>
                        <?php if ($user['role'] === 'admin'): ?><th class="text-end pe-3">Aksi</th><?php endif; ?>
                    </tr>
                </thead>
                <tbody>
                    <?php if (count($suppliers) === 0): ?>
                    <tr><td colspan="6" class="text-center py-4 text-muted">Belum ada supplier terdaftar.</td></tr>
                    <?php else: ?>
                    <?php foreach ($suppliers as $s): ?>
                    <tr>
                        <td class="ps-3"><strong><?= e($s['name']) ?></strong></td>
                        <td><?= e($s['contact_name'] ?: '-') ?></td>
                        <td>
                            <i class="fa-solid fa-phone text-muted me-1"></i><?= e($s['phone'] ?: '-') ?><br>
                            <i class="fa-solid fa-envelope text-muted me-1"></i><?= e($s['email'] ?: '-') ?>
                        </td>
                        <td class="small"><?= e($s['address'] ?: '-') ?></td>
                        <td class="text-center">
                            <span class="badge bg-secondary"><?= number_format($s['total_supplied_products']) ?> item</span>
                        </td>
                        <?php if ($user['role'] === 'admin'): ?>
                        <td class="text-end pe-3">
                            <a href="edit.php?id=<?= $s['id'] ?>" class="btn btn-sm btn-outline-primary me-1"><i class="fa-solid fa-pen-to-square"></i> Edit</a>
                            <a href="delete.php?id=<?= $s['id'] ?>" class="btn btn-sm btn-outline-danger" onclick="return confirm('Hapus supplier ini?');"><i class="fa-solid fa-trash"></i> Hapus</a>
                        </td>
                        <?php endif; ?>
                    </tr>
                    <?php endforeach; ?>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<?php include __DIR__ . '/../../views/footer.php'; ?>
