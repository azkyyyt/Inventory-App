<?php
// public/stock/out.php
// Transaksi Barang Keluar dengan Database Transaction & Business Rule (Slide 26, 27, 33)

require_once __DIR__ . '/../../config/database.php';
require_once __DIR__ . '/../../helpers/auth.php';
require_once __DIR__ . '/../../helpers/validation.php';
require_once __DIR__ . '/../../helpers/escape.php';

requireAuth(); // Admin & Staff boleh mencatat transaksi
$pdo = getPDO();
$currentUser = currentUser();

$errors = [];
$productId = filter_input(INPUT_GET, 'product_id', FILTER_VALIDATE_INT) ?: '';
$quantity = '';
$notes = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $productId = filter_input(INPUT_POST, 'product_id', FILTER_VALIDATE_INT);
    $quantityVal = trim($_POST['quantity'] ?? '');
    $notes = trim($_POST['notes'] ?? '');

    // 1. Syntactic Input Validation (Slide 21)
    if (!$productId || $productId <= 0) {
        $errors[] = 'Pilih produk yang valid.';
    }

    $validQty = validatePositiveInt($quantityVal);
    if ($validQty === false) {
        $errors[] = 'Jumlah (quantity) barang keluar harus berupa bilangan bulat positif (> 0).';
    }

    // 2. Execution with Database Transaction & Semantic Stock Check (Slide 26, 27, 33)
    if (empty($errors)) {
        $pdo->beginTransaction();
        try {
            // Step 1: SELECT stock ... FOR UPDATE (Slide 26)
            $isSqlite = $pdo->getAttribute(PDO::ATTR_DRIVER_NAME) === 'sqlite';
            $lockSql = $isSqlite 
                ? "SELECT id, name, stock FROM products WHERE id = :id" 
                : "SELECT id, name, stock FROM products WHERE id = :id FOR UPDATE";
            
            $stmtSelect = $pdo->prepare($lockSql);
            $stmtSelect->execute(['id' => $productId]);
            $targetProduct = $stmtSelect->fetch();

            if (!$targetProduct) {
                throw new Exception('Produk tidak ditemukan.');
            }

            // Step 2: Validasi quantity <= stock (Slide 26 & 33: Barang keluar tidak boleh melebihi stok, Stok tidak boleh menjadi negatif)
            $currentStock = (int) $targetProduct['stock'];
            if ($validQty > $currentStock) {
                throw new Exception('Jumlah barang keluar (' . $validQty . ' unit) melebihi stok yang tersedia (' . $currentStock . ' unit). Stok tidak boleh menjadi negatif.');
            }

            // Step 3: UPDATE products SET stock = stock - quantity (Slide 26)
            $stmtUpdateStock = $pdo->prepare("UPDATE products SET stock = stock - :qty WHERE id = :id");
            $stmtUpdateStock->execute(['qty' => $validQty, 'id' => $productId]);

            // Step 4: INSERT stock_movements (type = 'OUT') (Slide 26)
            $stmtInsertHistory = $pdo->prepare("
                INSERT INTO stock_movements (product_id, user_id, type, quantity, notes)
                VALUES (:product_id, :user_id, 'OUT', :quantity, :notes)
            ");
            $stmtInsertHistory->execute([
                'product_id' => $productId,
                'user_id' => $currentUser['id'],
                'quantity' => $validQty,
                'notes' => $notes ?: 'Pengeluaran barang / penjualan'
            ]);

            // Commit transaksi jika semua validasi lolos (Slide 26 & 27)
            $pdo->commit();

            $_SESSION['flash_success'] = 'Transaksi barang keluar berhasil! Stok ' . $targetProduct['name'] . ' berkurang ' . $validQty . ' unit (Sisa stok: ' . ($currentStock - $validQty) . ').';
            header("Location: history.php");
            exit;
        } catch (Throwable $e) {
            // Rollback jika terjadi kesalahan atau stok tidak mencukupi (Slide 26 & 27)
            $pdo->rollBack();
            $errors[] = $e->getMessage();
        }
    }
}

// Fetch list of products for dropdown
$products = $pdo->query("SELECT id, sku, name, stock FROM products ORDER BY name ASC")->fetchAll();

$pageTitle = 'Transaksi Barang Keluar (OUT)';
include __DIR__ . '/../../views/header.php';
?>

<div class="row justify-content-center">
    <div class="col-md-8 col-lg-6">
        <div class="card shadow-sm border-0">
            <div class="card-header bg-danger text-white py-3">
                <h5 class="mb-0 fw-bold"><i class="fa-solid fa-arrow-up me-2"></i>Transaksi Barang Keluar (OUT)</h5>
            </div>
            <div class="card-body p-4">
                <?php if (!empty($errors)): ?>
                    <div class="alert alert-danger shadow-sm">
                        <div class="fw-bold mb-1"><i class="fa-solid fa-triangle-exclamation me-1"></i> Transaksi Ditolak:</div>
                        <ul class="mb-0 ps-3">
                            <?php foreach ($errors as $err): ?>
                                <li><?= e($err) ?></li>
                            <?php endforeach; ?>
                        </ul>
                    </div>
                <?php endif; ?>

                <form method="POST" action="out.php">
                    <div class="mb-3">
                        <label for="product_id" class="form-label fw-semibold">Pilih Produk <span class="text-danger">*</span></label>
                        <select class="form-select" id="product_id" name="product_id" required>
                            <option value="">-- Pilih Produk --</option>
                            <?php foreach ($products as $p): ?>
                                <option value="<?= $p['id'] ?>" <?= ((int)$productId === (int)$p['id']) ? 'selected' : '' ?>>
                                    [<?= e($p['sku']) ?>] <?= e($p['name']) ?> (Stok tersedia: <?= $p['stock'] ?>)
                                </option>
                            <?php endforeach; ?>
                        </select>
                    </div>

                    <div class="mb-3">
                        <label for="quantity" class="form-label fw-semibold">Jumlah Barang Keluar (Quantity) <span class="text-danger">*</span></label>
                        <input type="number" class="form-control" id="quantity" name="quantity" value="<?= e($quantity) ?>" min="1" required placeholder="Contoh: 5">
                        <div class="form-text">Aturan bisnis: Jumlah barang keluar tidak boleh melebihi stok yang tersedia.</div>
                    </div>

                    <div class="mb-3">
                        <label for="notes" class="form-label fw-semibold">Catatan / Keterangan Transaksi</label>
                        <input type="text" class="form-control" id="notes" name="notes" value="<?= e($notes) ?>" placeholder="Contoh: Penjualan invoice #INV-1092">
                    </div>

                    <div class="d-flex justify-content-between align-items-center mt-4 pt-3 border-top">
                        <a href="../dashboard.php" class="btn btn-outline-secondary"><i class="fa-solid fa-arrow-left me-1"></i> Batal</a>
                        <button type="submit" class="btn btn-danger fw-bold"><i class="fa-solid fa-check-circle me-1"></i> Proses Barang Keluar</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>

<?php include __DIR__ . '/../../views/footer.php'; ?>
