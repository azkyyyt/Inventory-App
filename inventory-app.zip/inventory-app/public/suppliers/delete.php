<?php
// public/suppliers/delete.php
require_once __DIR__ . '/../../config/database.php';
require_once __DIR__ . '/../../helpers/auth.php';

requireRole('admin');
$pdo = getPDO();

$id = filter_input(INPUT_GET, 'id', FILTER_VALIDATE_INT);
if (!$id) {
    header("Location: index.php");
    exit;
}

$stmt = $pdo->prepare("SELECT name FROM suppliers WHERE id = :id");
$stmt->execute(['id' => $id]);
$supplier = $stmt->fetch();

if (!$supplier) {
    $_SESSION['flash_error'] = 'Supplier tidak ditemukan.';
    header("Location: index.php");
    exit;
}

try {
    $stmtDelete = $pdo->prepare("DELETE FROM suppliers WHERE id = :id");
    $stmtDelete->execute(['id' => $id]);
    $_SESSION['flash_success'] = 'Supplier "' . $supplier['name'] . '" berhasil dihapus.';
} catch (PDOException $e) {
    $_SESSION['flash_error'] = 'Gagal menghapus supplier: ' . $e->getMessage();
}

header("Location: index.php");
exit;
