<?php
// public/users/index.php
// Kelola User - Admin Only (Slide 24 & 33)

require_once __DIR__ . '/../../config/database.php';
require_once __DIR__ . '/../../helpers/auth.php';
require_once __DIR__ . '/../../helpers/escape.php';

// Slide 24 & 33: Authorization - Staff tidak boleh mengakses administrasi user (Returns 403 Forbidden)
requireRole('admin');
$pdo = getPDO();

$stmt = $pdo->query("
    SELECT u.id, u.username, u.role, u.created_at, up.full_name, up.phone
    FROM users u
    LEFT JOIN user_profiles up ON up.user_id = u.id
    ORDER BY u.id ASC
");
$usersList = $stmt->fetchAll();

$pageTitle = 'Kelola Pengguna';
include __DIR__ . '/../../views/header.php';
?>

<div class="d-flex justify-content-between align-items-center mb-3">
    <div>
        <h2 class="fw-bold mb-0">Kelola Pengguna (Users)</h2>
        <p class="text-muted small mb-0">Pengaturan akun dan hak akses pengguna sistem (Admin Only)</p>
    </div>
    <a href="create.php" class="btn btn-primary btn-sm">
        <i class="fa-solid fa-user-plus me-1"></i> Tambah User Baru
    </a>
</div>

<div class="card shadow-sm border-0 mb-4">
    <div class="card-body p-0">
        <div class="table-responsive">
            <table class="table table-hover align-middle mb-0">
                <thead class="table-dark">
                    <tr>
                        <th class="ps-3">ID</th>
                        <th>Username</th>
                        <th>Nama Lengkap (Profile)</th>
                        <th>No. Telepon</th>
                        <th class="text-center">Role / Hak Akses</th>
                        <th class="text-end pe-3">Aksi</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($usersList as $u): ?>
                    <tr>
                        <td class="ps-3">#<?= $u['id'] ?></td>
                        <td><code><?= e($u['username']) ?></code></td>
                        <td><strong><?= e($u['full_name'] ?: '-') ?></strong></td>
                        <td><?= e($u['phone'] ?: '-') ?></td>
                        <td class="text-center">
                            <span class="badge <?= $u['role'] === 'admin' ? 'bg-danger' : 'bg-primary' ?>">
                                <?= strtoupper(e($u['role'])) ?>
                            </span>
                        </td>
                        <td class="text-end pe-3">
                            <a href="edit.php?id=<?= $u['id'] ?>" class="btn btn-sm btn-outline-primary me-1"><i class="fa-solid fa-user-pen"></i> Edit</a>
                            <?php if ($u['id'] !== currentUser()['id']): ?>
                            <a href="delete.php?id=<?= $u['id'] ?>" class="btn btn-sm btn-outline-danger" onclick="return confirm('Hapus pengguna ini?');"><i class="fa-solid fa-user-xmark"></i> Hapus</a>
                            <?php endif; ?>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<?php include __DIR__ . '/../../views/footer.php'; ?>
