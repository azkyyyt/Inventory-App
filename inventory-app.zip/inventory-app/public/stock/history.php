<?php
// public/stock/history.php
// Menampilkan Histori Transaksi Barang Masuk dan Keluar (Slide 25, 26, 32)

require_once __DIR__ . '/../../config/database.php';
require_once __DIR__ . '/../../helpers/auth.php';
require_once __DIR__ . '/../../helpers/escape.php';

requireAuth();
$pdo = getPDO();

$typeFilter = $_GET['type'] ?? '';
$where = '';
$params = [];

if (in_array($typeFilter, ['IN', 'OUT'], true)) {
    $where = 'WHERE sm.type = :type';
    $params['type'] = $typeFilter;
}

$sql = "
    SELECT sm.id, sm.type, sm.quantity, sm.notes, sm.created_at,
           p.sku, p.name AS product_name, c.name AS category_name,
           u.username, COALESCE(up.full_name, u.username) AS user_full_name, u.role AS user_role
    FROM stock_movements sm
    JOIN products p ON p.id = sm.product_id
    JOIN categories c ON c.id = p.category_id
    JOIN users u ON u.id = sm.user_id
    LEFT JOIN user_profiles up ON up.user_id = u.id
    $where
    ORDER BY sm.created_at DESC, sm.id DESC
";

$stmt = $pdo->prepare($sql);
$stmt->execute($params);
$movements = $stmt->fetchAll();

$pageTitle = 'Histori Transaksi Stok';
include __DIR__ . '/../../views/header.php';
?>

<div class="d-flex justify-content-between align-items-center mb-3">
    <div>
        <h2 class="fw-bold mb-0">Histori Transaksi Stok</h2>
        <p class="text-muted small mb-0">Catatan lengkap mutasi barang masuk (IN) dan barang keluar (OUT)</p>
    </div>
    <div class="d-flex gap-2">
        <a href="in.php" class="btn btn-success btn-sm"><i class="fa-solid fa-plus me-1"></i> Barang Masuk</a>
        <a href="out.php" class="btn btn-danger btn-sm"><i class="fa-solid fa-minus me-1"></i> Barang Keluar</a>
    </div>
</div>

<!-- Filter Type -->
<div class="card shadow-sm border-0 mb-4">
    <div class="card-body bg-light py-2">
        <div class="d-flex align-items-center gap-2">
            <span class="fw-semibold small text-secondary">Filter Tipe Transaksi:</span>
            <a href="history.php" class="btn btn-sm <?= empty($typeFilter) ? 'btn-dark' : 'btn-outline-dark' ?>">Semua</a>
            <a href="history.php?type=IN" class="btn btn-sm <?= ($typeFilter === 'IN') ? 'btn-success' : 'btn-outline-success' ?>"><i class="fa-solid fa-arrow-down me-1"></i> Barang Masuk (IN)</a>
            <a href="history.php?type=OUT" class="btn btn-sm <?= ($typeFilter === 'OUT') ? 'btn-danger' : 'btn-outline-danger' ?>"><i class="fa-solid fa-arrow-up me-1"></i> Barang Keluar (OUT)</a>
        </div>
    </div>
</div>

<div class="card shadow-sm border-0 mb-4">
    <div class="card-body p-0">
        <div class="table-responsive">
            <table class="table table-hover align-middle mb-0">
                <thead class="table-dark">
                    <tr>
                        <th class="ps-3">Waktu &amp; Tanggal</th>
                        <th>Tipe</th>
                        <th>SKU / Nama Produk</th>
                        <th>Kategori</th>
                        <th class="text-center">Jumlah (Qty)</th>
                        <th>Petugas (User)</th>
                        <th class="pe-3">Catatan</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if (count($movements) === 0): ?>
                    <tr><td colspan="7" class="text-center py-4 text-muted">Belum ada data histori transaksi.</td></tr>
                    <?php else: ?>
                    <?php foreach ($movements as $m): ?>
                    <tr>
                        <td class="ps-3 text-muted small">
                            <i class="fa-regular fa-clock me-1"></i><?= e($m['created_at']) ?>
                        </td>
                        <td>
                            <?php if ($m['type'] === 'IN'): ?>
                                <span class="badge bg-success"><i class="fa-solid fa-arrow-down me-1"></i>MASUK</span>
                            <?php else: ?>
                                <span class="badge bg-danger"><i class="fa-solid fa-arrow-up me-1"></i>KELUAR</span>
                            <?php endif; ?>
                        </td>
                        <td>
                            <code><?= e($m['sku']) ?></code><br>
                            <strong><?= e($m['product_name']) ?></strong>
                        </td>
                        <td><span class="badge bg-light text-dark border"><?= e($m['category_name']) ?></span></td>
                        <td class="text-center font-monospace fw-bold fs-6 <?= $m['type'] === 'IN' ? 'text-success' : 'text-danger' ?>">
                            <?= $m['type'] === 'IN' ? '+' : '-' ?><?= number_format($m['quantity']) ?>
                        </td>
                        <td class="small">
                            <i class="fa-solid fa-user me-1 text-secondary"></i><?= e($m['user_full_name']) ?>
                            <span class="badge bg-secondary"><?= e($m['user_role']) ?></span>
                        </td>
                        <td class="pe-3 small text-muted"><?= e($m['notes'] ?: '-') ?></td>
                    </tr>
                    <?php endforeach; ?>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<?php include __DIR__ . '/../../views/header.php'; ?>
