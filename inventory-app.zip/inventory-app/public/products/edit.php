<?php
// public/products/edit.php
require_once __DIR__ . '/../../config/database.php';
require_once __DIR__ . '/../../helpers/auth.php';
require_once __DIR__ . '/../../helpers/validation.php';
require_once __DIR__ . '/../../helpers/escape.php';

requireRole('admin');
$pdo = getPDO();

$id = filter_input(INPUT_GET, 'id', FILTER_VALIDATE_INT);
if (!$id) {
    header("Location: index.php");
    exit;
}

$stmt = $pdo->prepare("SELECT * FROM products WHERE id = :id");
$stmt->execute(['id' => $id]);
$product = $stmt->fetch();

if (!$product) {
    $_SESSION['flash_error'] = 'Produk tidak ditemukan.';
    header("Location: index.php");
    exit;
}

$errors = [];
$sku = $product['sku'];
$name = $product['name'];
$categoryId = $product['category_id'];
$price = $product['price'];
$minimumStock = $product['minimum_stock'];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $sku = trim($_POST['sku'] ?? '');
    $name = trim($_POST['name'] ?? '');
    $categoryId = filter_input(INPUT_POST, 'category_id', FILTER_VALIDATE_INT);
    $priceVal = trim($_POST['price'] ?? '');
    $minStockVal = trim($_POST['minimum_stock'] ?? '');

    // Validation
    if (empty($sku)) {
        $errors[] = 'SKU wajib diisi.';
    } elseif (!isSkuUnique($pdo, $sku, $id)) {
        $errors[] = 'SKU "' . htmlspecialchars($sku) . '" sudah digunakan oleh produk lain.';
    }

    if (empty($name)) {
        $errors[] = 'Nama produk wajib diisi.';
    }

    if (!$categoryId || $categoryId <= 0) {
        $errors[] = 'Kategori wajib dipilih.';
    }

    $validPrice = validateNonNegativeFloat($priceVal);
    if ($validPrice === false) {
        $errors[] = 'Harga tidak boleh negatif dan harus berupa angka valid.';
    }

    $validMinStock = validateNonNegativeInt($minStockVal);
    if ($validMinStock === false) {
        $errors[] = 'Minimum stok tidak boleh negatif.';
    }

    if (empty($errors)) {
        $stmtUpdate = $pdo->prepare("
            UPDATE products 
            SET category_id = :category_id, sku = :sku, name = :name, price = :price, minimum_stock = :minimum_stock
            WHERE id = :id
        ");
        $stmtUpdate->execute([
            'category_id' => $categoryId,
            'sku' => $sku,
            'name' => $name,
            'price' => $validPrice,
            'minimum_stock' => $validMinStock,
            'id' => $id
        ]);

        $_SESSION['flash_success'] = 'Data produk "' . $name . '" berhasil diperbarui.';
        header("Location: index.php");
        exit;
    }
}

$categories = $pdo->query("SELECT id, name FROM categories ORDER BY name ASC")->fetchAll();

$pageTitle = 'Edit Produk';
include __DIR__ . '/../../views/header.php';
?>

<div class="row justify-content-center">
    <div class="col-md-8 col-lg-6">
        <div class="card shadow-sm border-0">
            <div class="card-header bg-dark text-white py-3">
                <h5 class="mb-0 fw-bold"><i class="fa-solid fa-pen-to-square me-2"></i>Edit Produk</h5>
            </div>
            <div class="card-body p-4">
                <?php if (!empty($errors)): ?>
                    <div class="alert alert-danger shadow-sm">
                        <div class="fw-bold mb-1"><i class="fa-solid fa-triangle-exclamation me-1"></i> Gagal memperbarui data:</div>
                        <ul class="mb-0 ps-3">
                            <?php foreach ($errors as $err): ?>
                                <li><?= e($err) ?></li>
                            <?php endforeach; ?>
                        </ul>
                    </div>
                <?php endif; ?>

                <form method="POST" action="edit.php?id=<?= $id ?>">
                    <div class="mb-3">
                        <label for="sku" class="form-label fw-semibold">SKU (Kode Barang) <span class="text-danger">*</span></label>
                        <input type="text" class="form-control" id="sku" name="sku" value="<?= e($sku) ?>" required>
                    </div>

                    <div class="mb-3">
                        <label for="name" class="form-label fw-semibold">Nama Produk <span class="text-danger">*</span></label>
                        <input type="text" class="form-control" id="name" name="name" value="<?= e($name) ?>" required>
                    </div>

                    <div class="mb-3">
                        <label for="category_id" class="form-label fw-semibold">Kategori <span class="text-danger">*</span></label>
                        <select class="form-select" id="category_id" name="category_id" required>
                            <option value="">-- Pilih Kategori --</option>
                            <?php foreach ($categories as $cat): ?>
                                <option value="<?= $cat['id'] ?>" <?= ((int)$categoryId === (int)$cat['id']) ? 'selected' : '' ?>>
                                    <?= e($cat['name']) ?>
                                </option>
                            <?php endforeach; ?>
                        </select>
                    </div>

                    <div class="mb-3">
                        <label for="price" class="form-label fw-semibold">Harga Satuan (Rp) <span class="text-danger">*</span></label>
                        <input type="number" step="0.01" class="form-control" id="price" name="price" value="<?= e($price) ?>" required>
                    </div>

                    <div class="mb-3">
                        <label for="minimum_stock" class="form-label fw-semibold">Minimum Stok Peringatan</label>
                        <input type="number" class="form-control" id="minimum_stock" name="minimum_stock" value="<?= e($minimumStock) ?>" min="0">
                    </div>

                    <div class="d-flex justify-content-between align-items-center mt-4 pt-3 border-top">
                        <a href="index.php" class="btn btn-outline-secondary"><i class="fa-solid fa-arrow-left me-1"></i> Batal</a>
                        <button type="submit" class="btn btn-primary fw-bold"><i class="fa-solid fa-floppy-disk me-1"></i> Simpan Perubahan</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>

<?php include __DIR__ . '/../../views/footer.php'; ?>
