<?php
// public/users/edit.php
require_once __DIR__ . '/../../config/database.php';
require_once __DIR__ . '/../../helpers/auth.php';
require_once __DIR__ . '/../../helpers/escape.php';

requireRole('admin');
$pdo = getPDO();

$id = filter_input(INPUT_GET, 'id', FILTER_VALIDATE_INT);
if (!$id) {
    header("Location: index.php");
    exit;
}

$stmt = $pdo->prepare("
    SELECT u.id, u.username, u.role, up.full_name, up.phone
    FROM users u
    LEFT JOIN user_profiles up ON up.user_id = u.id
    WHERE u.id = :id
");
$stmt->execute(['id' => $id]);
$targetUser = $stmt->fetch();

if (!$targetUser) {
    $_SESSION['flash_error'] = 'User tidak ditemukan.';
    header("Location: index.php");
    exit;
}

$errors = [];
$fullName = $targetUser['full_name'];
$phone = $targetUser['phone'];
$role = $targetUser['role'];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $fullName = trim($_POST['full_name'] ?? '');
    $phone = trim($_POST['phone'] ?? '');
    $role = $_POST['role'] ?? 'staff';
    $newPassword = $_POST['new_password'] ?? '';

    if (empty($fullName)) {
        $errors[] = 'Nama lengkap wajib diisi.';
    }

    if (!in_array($role, ['admin', 'staff'], true)) {
        $errors[] = 'Role tidak valid.';
    }

    if (!empty($newPassword) && strlen($newPassword) < 6) {
        $errors[] = 'Password baru minimal 6 karakter.';
    }

    if (empty($errors)) {
        $pdo->beginTransaction();
        try {
            if (!empty($newPassword)) {
                $hash = password_hash($newPassword, PASSWORD_DEFAULT);
                $stmtU = $pdo->prepare("UPDATE users SET role = :role, password_hash = :hash WHERE id = :id");
                $stmtU->execute(['role' => $role, 'hash' => $hash, 'id' => $id]);
            } else {
                $stmtU = $pdo->prepare("UPDATE users SET role = :role WHERE id = :id");
                $stmtU->execute(['role' => $role, 'id' => $id]);
            }

            // Update user_profiles
            $stmtProfCheck = $pdo->prepare("SELECT COUNT(*) FROM user_profiles WHERE user_id = :id");
            $stmtProfCheck->execute(['id' => $id]);
            if ((int)$stmtProfCheck->fetchColumn() > 0) {
                $stmtP = $pdo->prepare("UPDATE user_profiles SET full_name = :full_name, phone = :phone WHERE user_id = :id");
                $stmtP->execute(['full_name' => $fullName, 'phone' => $phone, 'id' => $id]);
            } else {
                $stmtP = $pdo->prepare("INSERT INTO user_profiles (user_id, full_name, phone) VALUES (:id, :full_name, :phone)");
                $stmtP->execute(['id' => $id, 'full_name' => $fullName, 'phone' => $phone]);
            }

            $pdo->commit();
            $_SESSION['flash_success'] = 'Pengguna "' . $targetUser['username'] . '" berhasil diperbarui.';
            header("Location: index.php");
            exit;
        } catch (Throwable $e) {
            $pdo->rollBack();
            $errors[] = 'Gagal memperbarui pengguna: ' . $e->getMessage();
        }
    }
}

$pageTitle = 'Edit User';
include __DIR__ . '/../../views/header.php';
?>

<div class="row justify-content-center">
    <div class="col-md-8 col-lg-6">
        <div class="card shadow-sm border-0">
            <div class="card-header bg-dark text-white py-3">
                <h5 class="mb-0 fw-bold"><i class="fa-solid fa-user-pen me-2"></i>Edit Pengguna</h5>
            </div>
            <div class="card-body p-4">
                <?php if (!empty($errors)): ?>
                    <div class="alert alert-danger shadow-sm">
                        <ul class="mb-0 ps-3">
                            <?php foreach ($errors as $err): ?>
                                <li><?= e($err) ?></li>
                            <?php endforeach; ?>
                        </ul>
                    </div>
                <?php endif; ?>

                <form method="POST" action="edit.php?id=<?= $id ?>">
                    <div class="mb-3">
                        <label class="form-label fw-semibold text-muted">Username</label>
                        <input type="text" class="form-control bg-light" value="<?= e($targetUser['username']) ?>" disabled>
                    </div>

                    <div class="mb-3">
                        <label for="new_password" class="form-label fw-semibold">Password Baru (Opsional)</label>
                        <input type="password" class="form-control" id="new_password" name="new_password" placeholder="Kosongkan jika tidak ingin mengubah password">
                    </div>

                    <div class="mb-3">
                        <label for="full_name" class="form-label fw-semibold">Nama Lengkap (Profile) <span class="text-danger">*</span></label>
                        <input type="text" class="form-control" id="full_name" name="full_name" value="<?= e($fullName) ?>" required>
                    </div>

                    <div class="mb-3">
                        <label for="phone" class="form-label fw-semibold">No. Telepon</label>
                        <input type="text" class="form-control" id="phone" name="phone" value="<?= e($phone) ?>">
                    </div>

                    <div class="mb-3">
                        <label for="role" class="form-label fw-semibold">Role / Hak Akses <span class="text-danger">*</span></label>
                        <select class="form-select" id="role" name="role" required>
                            <option value="staff" <?= ($role === 'staff') ? 'selected' : '' ?>>Staff</option>
                            <option value="admin" <?= ($role === 'admin') ? 'selected' : '' ?>>Admin</option>
                        </select>
                    </div>

                    <div class="d-flex justify-content-between align-items-center mt-4 pt-3 border-top">
                        <a href="index.php" class="btn btn-outline-secondary"><i class="fa-solid fa-arrow-left me-1"></i> Batal</a>
                        <button type="submit" class="btn btn-primary fw-bold"><i class="fa-solid fa-floppy-disk me-1"></i> Simpan Perubahan</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>

<?php include __DIR__ . '/../../views/footer.php'; ?>
