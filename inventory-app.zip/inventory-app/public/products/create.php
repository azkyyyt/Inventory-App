<?php
// public/products/create.php
require_once __DIR__ . '/../../config/database.php';
require_once __DIR__ . '/../../helpers/auth.php';
require_once __DIR__ . '/../../helpers/validation.php';
require_once __DIR__ . '/../../helpers/escape.php';

requireRole('admin'); // Only Admin can manage master data
$pdo = getPDO();

$errors = [];
$sku = '';
$name = '';
$categoryId = '';
$price = '';
$stock = '0';
$minimumStock = '5';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $sku = trim($_POST['sku'] ?? '');
    $name = trim($_POST['name'] ?? '');
    $categoryId = filter_input(INPUT_POST, 'category_id', FILTER_VALIDATE_INT);
    $priceVal = trim($_POST['price'] ?? '');
    $stockVal = trim($_POST['stock'] ?? '');
    $minStockVal = trim($_POST['minimum_stock'] ?? '');

    // 1. Syntactic & Semantic Validation (Slide 21 & 33)
    if (empty($sku)) {
        $errors[] = 'SKU wajib diisi.';
    } elseif (!isSkuUnique($pdo, $sku)) {
        $errors[] = 'SKU "' . htmlspecialchars($sku) . '" sudah digunakan. SKU harus unik.';
    }

    if (empty($name)) {
        $errors[] = 'Nama produk wajib diisi.';
    }

    if (!$categoryId || $categoryId <= 0) {
        $errors[] = 'Kategori wajib dipilih.';
    }

    $validPrice = validateNonNegativeFloat($priceVal);
    if ($validPrice === false) {
        $errors[] = 'Harga tidak boleh negatif dan harus berupa angka valid.';
    }

    $validStock = validateNonNegativeInt($stockVal);
    if ($validStock === false) {
        $errors[] = 'Stok tidak boleh negatif dan harus berupa bilangan bulat.';
    }

    $validMinStock = validateNonNegativeInt($minStockVal);
    if ($validMinStock === false) {
        $errors[] = 'Minimum stok tidak boleh negatif dan harus berupa bilangan bulat.';
    }

    // 2. Insert into database if valid
    if (empty($errors)) {
        $stmt = $pdo->prepare("
            INSERT INTO products (category_id, sku, name, price, stock, minimum_stock)
            VALUES (:category_id, :sku, :name, :price, :stock, :minimum_stock)
        ");
        $stmt->execute([
            'category_id' => $categoryId,
            'sku' => $sku,
            'name' => $name,
            'price' => $validPrice,
            'stock' => $validStock,
            'minimum_stock' => $validMinStock
        ]);

        $_SESSION['flash_success'] = 'Produk "' . $name . '" berhasil ditambahkan.';
        header("Location: index.php");
        exit;
    }
}

// Fetch categories for select dropdown
$categories = $pdo->query("SELECT id, name FROM categories ORDER BY name ASC")->fetchAll();

$pageTitle = 'Tambah Produk';
include __DIR__ . '/../../views/header.php';
?>

<div class="row justify-content-center">
    <div class="col-md-8 col-lg-6">
        <div class="card shadow-sm border-0">
            <div class="card-header bg-primary text-white py-3">
                <h5 class="mb-0 fw-bold"><i class="fa-solid fa-plus-circle me-2"></i>Tambah Produk Baru</h5>
            </div>
            <div class="card-body p-4">
                <?php if (!empty($errors)): ?>
                    <div class="alert alert-danger shadow-sm">
                        <div class="fw-bold mb-1"><i class="fa-solid fa-triangle-exclamation me-1"></i> Gagal menyimpan data:</div>
                        <ul class="mb-0 ps-3">
                            <?php foreach ($errors as $err): ?>
                                <li><?= e($err) ?></li>
                            <?php endforeach; ?>
                        </ul>
                    </div>
                <?php endif; ?>

                <form method="POST" action="create.php">
                    <div class="mb-3">
                        <label for="sku" class="form-label fw-semibold">SKU (Kode Barang) <span class="text-danger">*</span></label>
                        <input type="text" class="form-control" id="sku" name="sku" value="<?= e($sku) ?>" required placeholder="Contoh: SKU-KB-001">
                        <div class="form-text">SKU bersifat unik untuk setiap produk.</div>
                    </div>

                    <div class="mb-3">
                        <label for="name" class="form-label fw-semibold">Nama Produk <span class="text-danger">*</span></label>
                        <input type="text" class="form-control" id="name" name="name" value="<?= e($name) ?>" required placeholder="Contoh: Keyboard Mechanical">
                    </div>

                    <div class="mb-3">
                        <label for="category_id" class="form-label fw-semibold">Kategori <span class="text-danger">*</span></label>
                        <select class="form-select" id="category_id" name="category_id" required>
                            <option value="">-- Pilih Kategori --</option>
                            <?php foreach ($categories as $cat): ?>
                                <option value="<?= $cat['id'] ?>" <?= ((int)$categoryId === (int)$cat['id']) ? 'selected' : '' ?>>
                                    <?= e($cat['name']) ?>
                                </option>
                            <?php endforeach; ?>
                        </select>
                    </div>

                    <div class="mb-3">
                        <label for="price" class="form-label fw-semibold">Harga Satuan (Rp) <span class="text-danger">*</span></label>
                        <input type="number" step="0.01" class="form-control" id="price" name="price" value="<?= e($price) ?>" required placeholder="0">
                    </div>

                    <div class="row">
                        <div class="col-md-6 mb-3">
                            <label for="stock" class="form-label fw-semibold">Stok Awal</label>
                            <input type="number" class="form-control" id="stock" name="stock" value="<?= e($stock) ?>" min="0" placeholder="0">
                        </div>
                        <div class="col-md-6 mb-3">
                            <label for="minimum_stock" class="form-label fw-semibold">Minimum Stok Peringatan</label>
                            <input type="number" class="form-control" id="minimum_stock" name="minimum_stock" value="<?= e($minimumStock) ?>" min="0" placeholder="5">
                        </div>
                    </div>

                    <div class="d-flex justify-content-between align-items-center mt-4 pt-3 border-top">
                        <a href="index.php" class="btn btn-outline-secondary"><i class="fa-solid fa-arrow-left me-1"></i> Batal</a>
                        <button type="submit" class="btn btn-primary fw-bold"><i class="fa-solid fa-floppy-disk me-1"></i> Simpan Produk</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>

<?php include __DIR__ . '/../../views/footer.php'; ?>
