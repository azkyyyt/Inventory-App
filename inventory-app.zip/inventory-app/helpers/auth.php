<?php
// helpers/auth.php
// Menangani Authentication, Session management, dan Authorization (Slide 22, 23, 24)

function startSessionIfNeeded(): void {
    if (session_status() === PHP_SESSION_NONE) {
        session_start();
    }
}

function loginUser(array $user): void {
    startSessionIfNeeded();
    // Memperbarui session ID untuk mencegah session fixation attack (Slide 22 & 23)
    session_regenerate_id(true);
    $_SESSION['user'] = [
        'id' => (int) $user['id'],
        'username' => $user['username'],
        'role' => $user['role'],
        'full_name' => $user['full_name'] ?? $user['username']
    ];
}

function logoutUser(): void {
    startSessionIfNeeded();
    $_SESSION = [];
    if (ini_get("session.use_cookies")) {
        $params = session_get_cookie_params();
        setcookie(session_name(), '', time() - 42000,
            $params["path"], $params["domain"],
            $params["secure"], $params["httponly"]
        );
    }
    session_destroy();
}

function currentUser(): ?array {
    startSessionIfNeeded();
    return $_SESSION['user'] ?? null;
}

function isLoggedIn(): bool {
    return currentUser() !== null;
}

function requireAuth(): void {
    if (!isLoggedIn()) {
        $baseUrl = getBaseUrl();
        header("Location: " . $baseUrl . "/login.php");
        exit;
    }
}

function requireRole(array|string $allowedRoles): void {
    requireAuth();
    $user = currentUser();
    $roles = (array) $allowedRoles;

    if (!in_array($user['role'], $roles, true)) {
        http_response_code(403);
        $baseUrl = getBaseUrl();
        echo "<!DOCTYPE html><html lang='id'><head><meta charset='UTF-8'><title>403 - Akses Ditolak</title>";
        echo "<link rel='stylesheet' href='https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css'></head>";
        echo "<body class='bg-light d-flex align-items-center justify-content-center vh-100'>";
        echo "<div class='card shadow-sm p-4 text-center' style='max-width: 450px;'>";
        echo "<h1 class='text-danger display-4 fw-bold'>403</h1>";
        echo "<h4 class='mb-3'>Akses Ditolak (Forbidden)</h4>";
        echo "<p class='text-muted'>Anda tidak memiliki izin (role: <strong>" . htmlspecialchars($user['role']) . "</strong>) untuk mengakses halaman ini.</p>";
        echo "<a href='" . $baseUrl . "/dashboard.php' class='btn btn-primary mt-2'>Kembali ke Dashboard</a>";
        echo "</div></body></html>";
        exit;
    }
}

function getBaseUrl(): string {
    $scriptName = $_SERVER['SCRIPT_NAME'] ?? '';
    // Mencari posisi /public/ dalam URL
    $pos = strpos($scriptName, '/public');
    if ($pos !== false) {
        return substr($scriptName, 0, $pos + 7);
    }
    return '/public';
}
