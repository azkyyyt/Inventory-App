<?php
// public/stock/in.php
// Transaksi Barang Masuk dengan Database Transaction (Slide 25, 27)

require_once __DIR__ . '/../../config/database.php';
require_once __DIR__ . '/../../helpers/auth.php';
require_once __DIR__ . '/../../helpers/validation.php';
require_once __DIR__ . '/../../helpers/escape.php';

requireAuth(); // Admin & Staff boleh mencatat transaksi
$pdo = getPDO();
$currentUser = currentUser();

$errors = [];
$productId = filter_input(INPUT_GET, 'product_id', FILTER_VALIDATE_INT) ?: '';
$quantity = '';
$notes = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $productId = filter_input(INPUT_POST, 'product_id', FILTER_VALIDATE_INT);
    $quantityVal = trim($_POST['quantity'] ?? '');
    $notes = trim($_POST['notes'] ?? '');

    // 1. Syntactic & Semantic Input Validation (Slide 21)
    if (!$productId || $productId <= 0) {
        $errors[] = 'Pilih produk yang valid.';
    }

    $validQty = validatePositiveInt($quantityVal);
    if ($validQty === false) {
        $errors[] = 'Jumlah (quantity) barang masuk harus berupa bilangan bulat positif (> 0).';
    }

    if ($productId) {
        $stmtCheck = $pdo->prepare("SELECT id, name, stock FROM products WHERE id = :id");
        $stmtCheck->execute(['id' => $productId]);
        $targetProduct = $stmtCheck->fetch();
        if (!$targetProduct) {
            $errors[] = 'Produk tidak ditemukan.';
        }
    }

    // 2. Database Transaction Execution (Slide 25 & 27)
    if (empty($errors) && isset($targetProduct)) {
        $pdo->beginTransaction();
        try {
            // A. Update stok produk (stok = stok + quantity)
            $stmtUpdateStock = $pdo->prepare("UPDATE products SET stock = stock + :qty WHERE id = :id");
            $stmtUpdateStock->execute(['qty' => $validQty, 'id' => $productId]);

            // B. Catat histori transaksi stock_movements (type = 'IN')
            $stmtInsertHistory = $pdo->prepare("
                INSERT INTO stock_movements (product_id, user_id, type, quantity, notes)
                VALUES (:product_id, :user_id, 'IN', :quantity, :notes)
            ");
            $stmtInsertHistory->execute([
                'product_id' => $productId,
                'user_id' => $currentUser['id'],
                'quantity' => $validQty,
                'notes' => $notes ?: 'Penerimaan barang masuk'
            ]);

            // Commit transaksi jika semua berhasil (Slide 27)
            $pdo->commit();

            $_SESSION['flash_success'] = 'Transaksi barang masuk berhasil! Stok ' . $targetProduct['name'] . ' bertambah ' . $validQty . ' unit.';
            header("Location: history.php");
            exit;
        } catch (Throwable $e) {
            // Rollback jika terjadi kesalahan (Slide 27)
            $pdo->rollBack();
            $errors[] = 'Gagal memproses transaksi barang masuk: ' . $e->getMessage();
        }
    }
}

// Fetch list of products for dropdown
$products = $pdo->query("SELECT id, sku, name, stock FROM products ORDER BY name ASC")->fetchAll();

$pageTitle = 'Transaksi Barang Masuk (IN)';
include __DIR__ . '/../../views/header.php';
?>

<div class="row justify-content-center">
    <div class="col-md-8 col-lg-6">
        <div class="card shadow-sm border-0">
            <div class="card-header bg-success text-white py-3">
                <h5 class="mb-0 fw-bold"><i class="fa-solid fa-arrow-down me-2"></i>Transaksi Barang Masuk (IN)</h5>
            </div>
            <div class="card-body p-4">
                <?php if (!empty($errors)): ?>
                    <div class="alert alert-danger shadow-sm">
                        <div class="fw-bold mb-1"><i class="fa-solid fa-triangle-exclamation me-1"></i> Transaksi Gagal:</div>
                        <ul class="mb-0 ps-3">
                            <?php foreach ($errors as $err): ?>
                                <li><?= e($err) ?></li>
                            <?php endforeach; ?>
                        </ul>
                    </div>
                <?php endif; ?>

                <form method="POST" action="in.php">
                    <div class="mb-3">
                        <label for="product_id" class="form-label fw-semibold">Pilih Produk <span class="text-danger">*</span></label>
                        <select class="form-select" id="product_id" name="product_id" required>
                            <option value="">-- Pilih Produk --</option>
                            <?php foreach ($products as $p): ?>
                                <option value="<?= $p['id'] ?>" <?= ((int)$productId === (int)$p['id']) ? 'selected' : '' ?>>
                                    [<?= e($p['sku']) ?>] <?= e($p['name']) ?> (Stok saat ini: <?= $p['stock'] ?>)
                                </option>
                            <?php endforeach; ?>
                        </select>
                    </div>

                    <div class="mb-3">
                        <label for="quantity" class="form-label fw-semibold">Jumlah Barang Masuk (Quantity) <span class="text-danger">*</span></label>
                        <input type="number" class="form-control" id="quantity" name="quantity" value="<?= e($quantity) ?>" min="1" required placeholder="Contoh: 10">
                        <div class="form-text">Jumlah harus berupa bilangan positif lebih dari nol (> 0).</div>
                    </div>

                    <div class="mb-3">
                        <label for="notes" class="form-label fw-semibold">Catatan / Keterangan Transaksi</label>
                        <input type="text" class="form-control" id="notes" name="notes" value="<?= e($notes) ?>" placeholder="Contoh: Restok dari supplier PT Megah Tech">
                    </div>

                    <div class="d-flex justify-content-between align-items-center mt-4 pt-3 border-top">
                        <a href="../dashboard.php" class="btn btn-outline-secondary"><i class="fa-solid fa-arrow-left me-1"></i> Batal</a>
                        <button type="submit" class="btn btn-success fw-bold"><i class="fa-solid fa-check-circle me-1"></i> Proses Barang Masuk</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>

<?php include __DIR__ . '/../../views/footer.php'; ?>
