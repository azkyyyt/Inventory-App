<?php
// helpers/escape.php
// Mencegah XSS dengan Output Encoding (Slide 20)

if (!function_exists('e')) {
    /**
     * Escape HTML special characters for safe output.
     *
     * @param string|null $value
     * @return string
     */
    function e(?string $value): string {
        if ($value === null) {
            return '';
        }
        return htmlspecialchars($value, ENT_QUOTES, 'UTF-8');
    }
}
