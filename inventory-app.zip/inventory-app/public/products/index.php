<?php
// public/products/index.php
// Listing produk dengan Search, Filter, Sorting Allowlist, dan Pagination (Slide 16, 17, 33)

require_once __DIR__ . '/../../config/database.php';
require_once __DIR__ . '/../../helpers/auth.php';
require_once __DIR__ . '/../../helpers/validation.php';
require_once __DIR__ . '/../../helpers/escape.php';

requireAuth();
$pdo = getPDO();
$user = currentUser();

// 1. Parameter Handling (Search, Filter, Sorting, Pagination)
$search = trim($_GET['search'] ?? '');
$categoryId = filter_input(INPUT_GET, 'category_id', FILTER_VALIDATE_INT) ?: null;

// Allowlist sorting (Slide 16 & 33: Kolom sorting harus dipilih dari allowlist, bukan input mentah)
$allowedSortColumns = ['name' => 'p.name', 'price' => 'p.price', 'stock' => 'p.stock', 'sku' => 'p.sku', 'id' => 'p.id'];
$sortInput = $_GET['sort'] ?? 'id';
$sortCol = array_key_exists($sortInput, $allowedSortColumns) ? $allowedSortColumns[$sortInput] : 'p.id';
$sortDir = validateSortDirection($_GET['dir'] ?? 'ASC');

// Pagination (Slide 17)
$page = max(1, (int) ($_GET['page'] ?? 1));
$perPage = 10;
$offset = ($page - 1) * $perPage;

// 2. Query Builder dengan Conditions & Prepared Statement
$whereClauses = [];
$params = [];

if (!empty($search)) {
    $whereClauses[] = "(p.name LIKE :search OR p.sku LIKE :search)";
    $params['search'] = '%' . $search . '%';
}

if ($categoryId !== null && $categoryId > 0) {
    $whereClauses[] = "p.category_id = :category_id";
    $params['category_id'] = $categoryId;
}

$whereSql = '';
if (count($whereClauses) > 0) {
    $whereSql = 'WHERE ' . implode(' AND ', $whereClauses);
}

// 3. Count total records for pagination
$countSql = "SELECT COUNT(*) FROM products p $whereSql";
$stmtCount = $pdo->prepare($countSql);
$stmtCount->execute($params);
$totalRows = (int) $stmtCount->fetchColumn();
$totalPages = max(1, (int) ceil($totalRows / $perPage));

// 4. Fetch Products List
$dataSql = "
    SELECT p.id, p.sku, p.name, p.price, p.stock, p.minimum_stock, p.category_id, c.name AS category_name
    FROM products p
    JOIN categories c ON c.id = p.category_id
    $whereSql
    ORDER BY $sortCol $sortDir
    LIMIT :limit OFFSET :offset
";

$stmtData = $pdo->prepare($dataSql);
foreach ($params as $key => $val) {
    $stmtData->bindValue(':' . $key, $val);
}
$stmtData->bindValue(':limit', $perPage, PDO::PARAM_INT);
$stmtData->bindValue(':offset', $offset, PDO::PARAM_INT);
$stmtData->execute();
$products = $stmtData->fetchAll();

// Fetch categories for filter dropdown
$stmtCats = $pdo->query("SELECT id, name FROM categories ORDER BY name ASC");
$categories = $stmtCats->fetchAll();

// Helper URL builder for pagination & sorting preserving query params (Slide 17)
function buildUrl(array $newParams): string {
    $current = $_GET;
    $merged = array_merge($current, $newParams);
    return 'index.php?' . http_build_query($merged);
}

$pageTitle = 'Daftar Produk';
include __DIR__ . '/../../views/header.php';
?>

<div class="d-flex justify-content-between align-items-center mb-3">
    <div>
        <h2 class="fw-bold mb-0">Kelola Produk</h2>
        <p class="text-muted small mb-0">Master data produk inventory toko</p>
    </div>
    <?php if ($user['role'] === 'admin'): ?>
    <a href="create.php" class="btn btn-primary btn-sm">
        <i class="fa-solid fa-plus me-1"></i> Tambah Produk
    </a>
    <?php endif; ?>
</div>

<!-- Form Search, Filter, & Sorting -->
<div class="card shadow-sm border-0 mb-4">
    <div class="card-body bg-light">
        <form method="GET" action="index.php" class="row g-2 align-items-center">
            <!-- Search input -->
            <div class="col-md-4">
                <div class="input-group input-group-sm">
                    <span class="input-group-text bg-white"><i class="fa-solid fa-magnifying-glass"></i></span>
                    <input type="text" name="search" class="form-control" placeholder="Cari nama produk atau SKU..." value="<?= e($search) ?>">
                </div>
            </div>

            <!-- Category filter -->
            <div class="col-md-3">
                <select name="category_id" class="form-select form-select-sm">
                    <option value="">-- Semua Kategori --</option>
                    <?php foreach ($categories as $cat): ?>
                        <option value="<?= $cat['id'] ?>" <?= ($categoryId === (int)$cat['id']) ? 'selected' : '' ?>>
                            <?= e($cat['name']) ?>
                        </option>
                    <?php endforeach; ?>
                </select>
            </div>

            <!-- Sort By -->
            <div class="col-md-2">
                <select name="sort" class="form-select form-select-sm">
                    <option value="id" <?= ($sortInput === 'id') ? 'selected' : '' ?>>Urut: ID</option>
                    <option value="name" <?= ($sortInput === 'name') ? 'selected' : '' ?>>Urut: Nama</option>
                    <option value="sku" <?= ($sortInput === 'sku') ? 'selected' : '' ?>>Urut: SKU</option>
                    <option value="price" <?= ($sortInput === 'price') ? 'selected' : '' ?>>Urut: Harga</option>
                    <option value="stock" <?= ($sortInput === 'stock') ? 'selected' : '' ?>>Urut: Stok</option>
                </select>
            </div>

            <!-- Sort Direction -->
            <div class="col-md-2">
                <select name="dir" class="form-select form-select-sm">
                    <option value="ASC" <?= ($sortDir === 'ASC') ? 'selected' : '' ?>>Menaik (ASC)</option>
                    <option value="DESC" <?= ($sortDir === 'DESC') ? 'selected' : '' ?>>Menurun (DESC)</option>
                </select>
            </div>

            <!-- Submit Button & Reset -->
            <div class="col-md-1 d-flex gap-1">
                <button type="submit" class="btn btn-sm btn-dark w-100"><i class="fa-solid fa-filter"></i></button>
                <a href="index.php" class="btn btn-sm btn-outline-secondary"><i class="fa-solid fa-rotate-left"></i></a>
            </div>
        </form>
    </div>
</div>

<!-- Table Listing -->
<div class="card shadow-sm border-0 mb-4">
    <div class="card-body p-0">
        <div class="table-responsive">
            <table class="table table-hover align-middle mb-0">
                <thead class="table-dark">
                    <tr>
                        <th class="ps-3">SKU</th>
                        <th>
                            <a href="<?= buildUrl(['sort' => 'name', 'dir' => ($sortInput === 'name' && $sortDir === 'ASC') ? 'DESC' : 'ASC']) ?>" class="text-white text-decoration-none">
                                Nama Produk <?= ($sortInput === 'name') ? ($sortDir === 'ASC' ? '▲' : '▼') : '' ?>
                            </a>
                        </th>
                        <th>Kategori</th>
                        <th class="text-end">
                            <a href="<?= buildUrl(['sort' => 'price', 'dir' => ($sortInput === 'price' && $sortDir === 'ASC') ? 'DESC' : 'ASC']) ?>" class="text-white text-decoration-none">
                                Harga <?= ($sortInput === 'price') ? ($sortDir === 'ASC' ? '▲' : '▼') : '' ?>
                            </a>
                        </th>
                        <th class="text-center">
                            <a href="<?= buildUrl(['sort' => 'stock', 'dir' => ($sortInput === 'stock' && $sortDir === 'ASC') ? 'DESC' : 'ASC']) ?>" class="text-white text-decoration-none">
                                Stok <?= ($sortInput === 'stock') ? ($sortDir === 'ASC' ? '▲' : '▼') : '' ?>
                            </a>
                        </th>
                        <th class="text-center">Min. Stok</th>
                        <th class="text-end pe-3">Aksi</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if (count($products) === 0): ?>
                    <tr><td colspan="7" class="text-center py-4 text-muted">Tidak ada produk yang ditemukan.</td></tr>
                    <?php else: ?>
                    <?php foreach ($products as $p): ?>
                    <tr>
                        <td class="ps-3"><code><?= e($p['sku']) ?></code></td>
                        <td><strong><?= e($p['name']) ?></strong></td>
                        <td><span class="badge bg-secondary"><?= e($p['category_name']) ?></span></td>
                        <td class="text-end">Rp <?= number_format($p['price'], 0, ',', '.') ?></td>
                        <td class="text-center">
                            <?php if ($p['stock'] <= $p['minimum_stock']): ?>
                                <span class="badge bg-danger" title="Stok berada di bawah atau sama dengan batas minimum!"><?= number_format($p['stock']) ?></span>
                            <?php else: ?>
                                <span class="badge bg-success"><?= number_format($p['stock']) ?></span>
                            <?php endif; ?>
                        </td>
                        <td class="text-center text-muted"><?= number_format($p['minimum_stock']) ?></td>
                        <td class="text-end pe-3">
                            <a href="suppliers.php?id=<?= $p['id'] ?>" class="btn btn-sm btn-outline-info me-1" title="Kelola Supplier (Many-to-Many)">
                                <i class="fa-solid fa-truck-field"></i> Supplier
                            </a>
                            <?php if ($user['role'] === 'admin'): ?>
                            <a href="edit.php?id=<?= $p['id'] ?>" class="btn btn-sm btn-outline-primary me-1" title="Edit Produk">
                                <i class="fa-solid fa-pen-to-square"></i>
                            </a>
                            <a href="delete.php?id=<?= $p['id'] ?>" class="btn btn-sm btn-outline-danger" onclick="return confirm('Apakah Anda yakin ingin menghapus produk ini?');" title="Hapus Produk">
                                <i class="fa-solid fa-trash"></i>
                            </a>
                            <?php endif; ?>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>

    <!-- Pagination Controls (Slide 17) -->
    <?php if ($totalPages > 1): ?>
    <div class="card-footer bg-white d-flex justify-content-between align-items-center py-2">
        <small class="text-muted">
            Menampilkan halaman <strong><?= $page ?></strong> dari <strong><?= $totalPages ?></strong> (Total <?= $totalRows ?> data)
        </small>
        <nav>
            <ul class="pagination pagination-sm mb-0">
                <li class="page-item <?= ($page <= 1) ? 'disabled' : '' ?>">
                    <a class="page-link" href="<?= buildUrl(['page' => $page - 1]) ?>">Sebelumnya</a>
                </li>
                <?php for ($i = 1; $i <= $totalPages; $i++): ?>
                    <li class="page-item <?= ($page === $i) ? 'active' : '' ?>">
                        <a class="page-link" href="<?= buildUrl(['page' => $i]) ?>"><?= $i ?></a>
                    </li>
                <?php endfor; ?>
                <li class="page-item <?= ($page >= $totalPages) ? 'disabled' : '' ?>">
                    <a class="page-link" href="<?= buildUrl(['page' => $page + 1]) ?>">Selanjutnya</a>
                </li>
            </ul>
        </nav>
    </div>
    <?php endif; ?>
</div>

<?php include __DIR__ . '/../../views/header.php'; ?>
