<?php
// config/database.php
// Menangani koneksi PDO ke Database (MySQL / MariaDB atau Fallback SQLite)
// Termasuk auto-inisialisasi tabel & seed data jika database masih kosong.

define('DB_HOST', getenv('DB_HOST') ?: '127.0.0.1');
define('DB_PORT', getenv('DB_PORT') ?: '3306');
define('DB_NAME', getenv('DB_NAME') ?: 'inventory_db');
define('DB_USER', getenv('DB_USER') ?: 'root');
define('DB_PASS', getenv('DB_PASS') ?: '');

function getPDO(): PDO {
    static $pdo = null;
    if ($pdo !== null) {
        return $pdo;
    }

    $useSqlite = getenv('USE_SQLITE') === '1' || getenv('USE_SQLITE') === 'true';

    if (!$useSqlite) {
        try {
            $dsn = sprintf("mysql:host=%s;port=%s;dbname=%s;charset=utf8mb4", DB_HOST, DB_PORT, DB_NAME);
            $pdo = new PDO($dsn, DB_USER, DB_PASS, [
                PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
                PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
                PDO::ATTR_EMULATE_PREPARES => false,
            ]);
            initDatabaseIfNeeded($pdo, 'mysql');
            return $pdo;
        } catch (PDOException $e) {
            // Jika gagal koneksi MySQL, fallback ke SQLite
            $sqliteFile = __DIR__ . '/../database/inventory.sqlite';
            $pdo = new PDO("sqlite:" . $sqliteFile);
            $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
            $pdo->setAttribute(PDO::ATTR_DEFAULT_FETCH_MODE, PDO::FETCH_ASSOC);
            $pdo->exec("PRAGMA foreign_keys = ON;");
            initDatabaseIfNeeded($pdo, 'sqlite');
            return $pdo;
        }
    } else {
        $sqliteFile = __DIR__ . '/../database/inventory.sqlite';
        $pdo = new PDO("sqlite:" . $sqliteFile);
        $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
        $pdo->setAttribute(PDO::ATTR_DEFAULT_FETCH_MODE, PDO::FETCH_ASSOC);
        $pdo->exec("PRAGMA foreign_keys = ON;");
        initDatabaseIfNeeded($pdo, 'sqlite');
        return $pdo;
    }
}

/**
 * Cek apakah tabel 'users' sudah ada. Jika belum, buat semua tabel & isi seed data.
 * Fungsi ini berjalan otomatis & silent (tidak menampilkan apapun ke browser).
 */
function initDatabaseIfNeeded(PDO $pdo, string $driver): void {
    // Cek apakah tabel users sudah ada
    try {
        $pdo->query("SELECT 1 FROM users LIMIT 1");
        return; // Tabel sudah ada, tidak perlu inisialisasi
    } catch (PDOException $e) {
        // Tabel belum ada, lanjut inisialisasi
    }

    if ($driver === 'mysql') {
        createMysqlTables($pdo);
    } else {
        createSqliteTables($pdo);
    }
    seedData($pdo);
}

function createMysqlTables(PDO $pdo): void {
    $pdo->exec("CREATE TABLE IF NOT EXISTS `users` (
        `id` INT AUTO_INCREMENT PRIMARY KEY,
        `username` VARCHAR(50) NOT NULL UNIQUE,
        `password_hash` VARCHAR(255) NOT NULL,
        `role` ENUM('admin', 'staff') NOT NULL DEFAULT 'staff',
        `created_at` DATETIME DEFAULT CURRENT_TIMESTAMP
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");

    $pdo->exec("CREATE TABLE IF NOT EXISTS `user_profiles` (
        `id` INT AUTO_INCREMENT PRIMARY KEY,
        `user_id` INT NOT NULL UNIQUE,
        `full_name` VARCHAR(100) NOT NULL,
        `phone` VARCHAR(20) DEFAULT NULL,
        `created_at` DATETIME DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (`user_id`) REFERENCES `users`(`id`) ON UPDATE CASCADE ON DELETE CASCADE
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");

    $pdo->exec("CREATE TABLE IF NOT EXISTS `categories` (
        `id` INT AUTO_INCREMENT PRIMARY KEY,
        `name` VARCHAR(100) NOT NULL UNIQUE,
        `description` TEXT DEFAULT NULL,
        `created_at` DATETIME DEFAULT CURRENT_TIMESTAMP
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");

    $pdo->exec("CREATE TABLE IF NOT EXISTS `suppliers` (
        `id` INT AUTO_INCREMENT PRIMARY KEY,
        `name` VARCHAR(150) NOT NULL,
        `contact_name` VARCHAR(100) DEFAULT NULL,
        `phone` VARCHAR(30) DEFAULT NULL,
        `email` VARCHAR(100) DEFAULT NULL,
        `address` TEXT DEFAULT NULL,
        `created_at` DATETIME DEFAULT CURRENT_TIMESTAMP
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");

    $pdo->exec("CREATE TABLE IF NOT EXISTS `products` (
        `id` INT AUTO_INCREMENT PRIMARY KEY,
        `category_id` INT NOT NULL,
        `sku` VARCHAR(50) NOT NULL UNIQUE,
        `name` VARCHAR(150) NOT NULL,
        `price` DECIMAL(12,2) NOT NULL,
        `stock` INT NOT NULL DEFAULT 0,
        `minimum_stock` INT NOT NULL DEFAULT 5,
        `created_at` DATETIME DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (`category_id`) REFERENCES `categories`(`id`) ON UPDATE CASCADE ON DELETE RESTRICT
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");

    $pdo->exec("CREATE TABLE IF NOT EXISTS `product_suppliers` (
        `product_id` INT NOT NULL,
        `supplier_id` INT NOT NULL,
        `supplier_price` DECIMAL(12,2) DEFAULT NULL,
        PRIMARY KEY (`product_id`, `supplier_id`),
        FOREIGN KEY (`product_id`) REFERENCES `products`(`id`) ON UPDATE CASCADE ON DELETE CASCADE,
        FOREIGN KEY (`supplier_id`) REFERENCES `suppliers`(`id`) ON UPDATE CASCADE ON DELETE CASCADE
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");

    $pdo->exec("CREATE TABLE IF NOT EXISTS `stock_movements` (
        `id` INT AUTO_INCREMENT PRIMARY KEY,
        `product_id` INT NOT NULL,
        `user_id` INT NOT NULL,
        `type` ENUM('IN', 'OUT') NOT NULL,
        `quantity` INT NOT NULL,
        `notes` VARCHAR(255) DEFAULT NULL,
        `created_at` DATETIME DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (`product_id`) REFERENCES `products`(`id`) ON UPDATE CASCADE ON DELETE RESTRICT,
        FOREIGN KEY (`user_id`) REFERENCES `users`(`id`) ON UPDATE CASCADE ON DELETE RESTRICT
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
}

function createSqliteTables(PDO $pdo): void {
    $pdo->exec("CREATE TABLE IF NOT EXISTS `users` (
        `id` INTEGER PRIMARY KEY AUTOINCREMENT,
        `username` TEXT NOT NULL UNIQUE,
        `password_hash` TEXT NOT NULL,
        `role` TEXT NOT NULL DEFAULT 'staff' CHECK(role IN ('admin','staff')),
        `created_at` TEXT DEFAULT (datetime('now','localtime'))
    )");

    $pdo->exec("CREATE TABLE IF NOT EXISTS `user_profiles` (
        `id` INTEGER PRIMARY KEY AUTOINCREMENT,
        `user_id` INTEGER NOT NULL UNIQUE,
        `full_name` TEXT NOT NULL,
        `phone` TEXT DEFAULT NULL,
        `created_at` TEXT DEFAULT (datetime('now','localtime')),
        FOREIGN KEY (`user_id`) REFERENCES `users`(`id`) ON UPDATE CASCADE ON DELETE CASCADE
    )");

    $pdo->exec("CREATE TABLE IF NOT EXISTS `categories` (
        `id` INTEGER PRIMARY KEY AUTOINCREMENT,
        `name` TEXT NOT NULL UNIQUE,
        `description` TEXT DEFAULT NULL,
        `created_at` TEXT DEFAULT (datetime('now','localtime'))
    )");

    $pdo->exec("CREATE TABLE IF NOT EXISTS `suppliers` (
        `id` INTEGER PRIMARY KEY AUTOINCREMENT,
        `name` TEXT NOT NULL,
        `contact_name` TEXT DEFAULT NULL,
        `phone` TEXT DEFAULT NULL,
        `email` TEXT DEFAULT NULL,
        `address` TEXT DEFAULT NULL,
        `created_at` TEXT DEFAULT (datetime('now','localtime'))
    )");

    $pdo->exec("CREATE TABLE IF NOT EXISTS `products` (
        `id` INTEGER PRIMARY KEY AUTOINCREMENT,
        `category_id` INTEGER NOT NULL,
        `sku` TEXT NOT NULL UNIQUE,
        `name` TEXT NOT NULL,
        `price` REAL NOT NULL,
        `stock` INTEGER NOT NULL DEFAULT 0,
        `minimum_stock` INTEGER NOT NULL DEFAULT 5,
        `created_at` TEXT DEFAULT (datetime('now','localtime')),
        FOREIGN KEY (`category_id`) REFERENCES `categories`(`id`) ON UPDATE CASCADE ON DELETE RESTRICT
    )");

    $pdo->exec("CREATE TABLE IF NOT EXISTS `product_suppliers` (
        `product_id` INTEGER NOT NULL,
        `supplier_id` INTEGER NOT NULL,
        `supplier_price` REAL DEFAULT NULL,
        PRIMARY KEY (`product_id`, `supplier_id`),
        FOREIGN KEY (`product_id`) REFERENCES `products`(`id`) ON UPDATE CASCADE ON DELETE CASCADE,
        FOREIGN KEY (`supplier_id`) REFERENCES `suppliers`(`id`) ON UPDATE CASCADE ON DELETE CASCADE
    )");

    $pdo->exec("CREATE TABLE IF NOT EXISTS `stock_movements` (
        `id` INTEGER PRIMARY KEY AUTOINCREMENT,
        `product_id` INTEGER NOT NULL,
        `user_id` INTEGER NOT NULL,
        `type` TEXT NOT NULL CHECK(type IN ('IN','OUT')),
        `quantity` INTEGER NOT NULL,
        `notes` TEXT DEFAULT NULL,
        `created_at` TEXT DEFAULT (datetime('now','localtime')),
        FOREIGN KEY (`product_id`) REFERENCES `products`(`id`) ON UPDATE CASCADE ON DELETE RESTRICT,
        FOREIGN KEY (`user_id`) REFERENCES `users`(`id`) ON UPDATE CASCADE ON DELETE RESTRICT
    )");
}

/**
 * Isi seed data: users, profiles, categories, suppliers, products, relasi, transaksi.
 * Password di-hash menggunakan password_hash() agar password_verify() selalu cocok.
 */
function seedData(PDO $pdo): void {
    // Users — hash BENAR di-generate saat runtime
    $adminHash = password_hash('admin123', PASSWORD_BCRYPT);
    $staffHash = password_hash('staff123', PASSWORD_BCRYPT);

    $stmt = $pdo->prepare("INSERT INTO users (id, username, password_hash, role) VALUES (?, ?, ?, ?)");
    $stmt->execute([1, 'admin', $adminHash, 'admin']);
    $stmt->execute([2, 'staff', $staffHash, 'staff']);

    // User Profiles
    $stmt = $pdo->prepare("INSERT INTO user_profiles (id, user_id, full_name, phone) VALUES (?, ?, ?, ?)");
    $stmt->execute([1, 1, 'Administrator Utama', '081234567890']);
    $stmt->execute([2, 2, 'Staff Gudang', '081298765432']);

    // Categories
    $stmt = $pdo->prepare("INSERT INTO categories (id, name, description) VALUES (?, ?, ?)");
    $stmt->execute([1, 'Elektronik', 'Peralatan elektronik dan periferal komputer']);
    $stmt->execute([2, 'Aksesori', 'Aksesori pendukung gadget dan komputer']);
    $stmt->execute([3, 'Alat Tulis Kantor', 'Perlengkapan dan peralatan kantor']);

    // Suppliers
    $stmt = $pdo->prepare("INSERT INTO suppliers (id, name, contact_name, phone, email, address) VALUES (?, ?, ?, ?, ?, ?)");
    $stmt->execute([1, 'PT Megah Utama Tech', 'Budi Santoso', '021-5551234', 'budi@megahtech.com', 'Jl. Industri No. 45, Jakarta']);
    $stmt->execute([2, 'CV Aksesori Nusantara', 'Siti Rahma', '022-4445678', 'siti@aksa.co.id', 'Jl. Raya Bandung No. 12, Bandung']);

    // Products
    $stmt = $pdo->prepare("INSERT INTO products (id, category_id, sku, name, price, stock, minimum_stock) VALUES (?, ?, ?, ?, ?, ?, ?)");
    $stmt->execute([1, 1, 'SKU-KB-001', 'Keyboard Mechanical RGB', 450000.00, 25, 5]);
    $stmt->execute([2, 1, 'SKU-MS-002', 'Mouse Wireless Ergonomis', 175000.00, 4, 10]);
    $stmt->execute([3, 2, 'SKU-MP-003', 'Mousepad Gaming XL', 85000.00, 50, 8]);
    $stmt->execute([4, 3, 'SKU-KRT-004', 'Kertas A4 80gr Rim', 55000.00, 2, 15]);

    // Product Suppliers (junction table many-to-many)
    $stmt = $pdo->prepare("INSERT INTO product_suppliers (product_id, supplier_id, supplier_price) VALUES (?, ?, ?)");
    $stmt->execute([1, 1, 380000.00]);
    $stmt->execute([2, 1, 140000.00]);
    $stmt->execute([3, 2, 60000.00]);

    // Stock Movements
    $stmt = $pdo->prepare("INSERT INTO stock_movements (id, product_id, user_id, type, quantity, notes) VALUES (?, ?, ?, ?, ?, ?)");
    $stmt->execute([1, 1, 1, 'IN', 25, 'Stok awal gudang']);
    $stmt->execute([2, 2, 1, 'IN', 10, 'Stok awal gudang']);
    $stmt->execute([3, 2, 2, 'OUT', 6, 'Penjualan ke pelanggan']);
    $stmt->execute([4, 3, 1, 'IN', 50, 'Stok awal gudang']);
    $stmt->execute([5, 4, 1, 'IN', 2, 'Stok awal gudang']);
}
