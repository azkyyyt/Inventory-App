<?php
// public/products/delete.php
// Menangani penghapusan produk dengan Referential Integrity (Slide 9 & 33)

require_once __DIR__ . '/../../config/database.php';
require_once __DIR__ . '/../../helpers/auth.php';

requireRole('admin');
$pdo = getPDO();

$id = filter_input(INPUT_GET, 'id', FILTER_VALIDATE_INT);
if (!$id) {
    header("Location: index.php");
    exit;
}

$stmt = $pdo->prepare("SELECT name FROM products WHERE id = :id");
$stmt->execute(['id' => $id]);
$product = $stmt->fetch();

if (!$product) {
    $_SESSION['flash_error'] = 'Produk tidak ditemukan.';
    header("Location: index.php");
    exit;
}

// 1. Cek apakah produk memiliki histori transaksi di stock_movements (Slide 33: Produk yang memiliki histori tidak boleh dihapus sembarangan)
$stmtHistory = $pdo->prepare("SELECT COUNT(*) FROM stock_movements WHERE product_id = :id");
$stmtHistory->execute(['id' => $id]);
$historyCount = (int) $stmtHistory->fetchColumn();

if ($historyCount > 0) {
    $_SESSION['flash_error'] = 'Gagal menghapus produk "' . $product['name'] . '". Produk ini telah memiliki ' . $historyCount . ' histori transaksi barang masuk/keluar (Referential Integrity Constraint).';
    header("Location: index.php");
    exit;
}

// 2. Jika tidak ada histori, hapus produk (dan junction product_suppliers akan terhapus via CASCADE)
try {
    $stmtDelete = $pdo->prepare("DELETE FROM products WHERE id = :id");
    $stmtDelete->execute(['id' => $id]);
    $_SESSION['flash_success'] = 'Produk "' . $product['name'] . '" berhasil dihapus.';
} catch (PDOException $e) {
    $_SESSION['flash_error'] = 'Gagal menghapus produk: ' . $e->getMessage();
}

header("Location: index.php");
exit;
