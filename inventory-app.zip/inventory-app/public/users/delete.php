<?php
// public/users/delete.php
require_once __DIR__ . '/../../config/database.php';
require_once __DIR__ . '/../../helpers/auth.php';

requireRole('admin');
$pdo = getPDO();

$id = filter_input(INPUT_GET, 'id', FILTER_VALIDATE_INT);
if (!$id) {
    header("Location: index.php");
    exit;
}

$currentUser = currentUser();
if ($id === $currentUser['id']) {
    $_SESSION['flash_error'] = 'Anda tidak dapat menghapus akun Anda sendiri yang sedang aktif.';
    header("Location: index.php");
    exit;
}

$stmt = $pdo->prepare("SELECT username FROM users WHERE id = :id");
$stmt->execute(['id' => $id]);
$targetUser = $stmt->fetch();

if (!$targetUser) {
    $_SESSION['flash_error'] = 'User tidak ditemukan.';
    header("Location: index.php");
    exit;
}

// Check stock movements constraint (ON DELETE RESTRICT)
$stmtMov = $pdo->prepare("SELECT COUNT(*) FROM stock_movements WHERE user_id = :id");
$stmtMov->execute(['id' => $id]);
$movCount = (int) $stmtMov->fetchColumn();

if ($movCount > 0) {
    $_SESSION['flash_error'] = 'Gagal menghapus user "' . $targetUser['username'] . '". User ini tercatat pada ' . $movCount . ' transaksi histori barang masuk/keluar.';
    header("Location: index.php");
    exit;
}

try {
    $stmtDelete = $pdo->prepare("DELETE FROM users WHERE id = :id");
    $stmtDelete->execute(['id' => $id]);
    $_SESSION['flash_success'] = 'User "' . $targetUser['username'] . '" berhasil dihapus.';
} catch (PDOException $e) {
    $_SESSION['flash_error'] = 'Gagal menghapus user: ' . $e->getMessage();
}

header("Location: index.php");
exit;
