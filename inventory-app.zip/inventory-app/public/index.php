<?php
// public/index.php
require_once __DIR__ . '/../helpers/auth.php';

startSessionIfNeeded();
if (isLoggedIn()) {
    header("Location: dashboard.php");
} else {
    header("Location: login.php");
}
exit;
