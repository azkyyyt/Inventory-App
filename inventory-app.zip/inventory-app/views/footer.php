<?php
// views/footer.php
?>
</div> <!-- End Container -->

<footer class="footer mt-auto py-3 bg-white border-top text-center text-muted">
    <div class="container">
        <small>&copy; <?= date('Y') ?> Inventory Management System — Pertemuan 4: Relational Database &amp; Advanced PHP</small>
    </div>
</footer>

<!-- Bootstrap 5 JS Bundle -->
<script href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
