<?php
// tests/verify_project.php
// Automated Verification & Compliance Audit Suite for Mini Project 3 — Inventory Management System

require_once __DIR__ . '/../helpers/escape.php';
require_once __DIR__ . '/../helpers/validation.php';
require_once __DIR__ . '/../helpers/auth.php';

echo "=====================================================================\n";
echo "   MINI PROJECT 3 - AUTOMATED CODE VERIFICATION & AUDIT SUITE\n";
echo "=====================================================================\n\n";

$passCount = 0;
$totalCount = 0;

function assertCheck(bool $condition, string $title, string $detail = ''): void {
    global $passCount, $totalCount;
    $totalCount++;
    if ($condition) {
        $passCount++;
        echo " [PASS] Test #{$totalCount}: {$title}\n";
        if ($detail) echo "        └─ {$detail}\n";
    } else {
        echo "![FAIL] Test #{$totalCount}: {$title}\n";
        if ($detail) echo "        └─ {$detail}\n";
    }
}

// 1. Audit Slide 34 Directory Structure Compliance
$expectedFiles = [
    'config/database.php',
    'helpers/auth.php',
    'helpers/validation.php',
    'helpers/escape.php',
    'public/login.php',
    'public/logout.php',
    'public/dashboard.php',
    'public/products/index.php',
    'public/products/create.php',
    'public/products/edit.php',
    'public/products/delete.php',
    'public/products/suppliers.php',
    'public/stock/in.php',
    'public/stock/out.php',
    'public/stock/history.php',
    'views/header.php',
    'views/footer.php',
    'database/schema.sql'
];

$allExist = true;
$missing = [];
foreach ($expectedFiles as $relPath) {
    $fullPath = __DIR__ . '/../' . $relPath;
    if (!file_exists($fullPath)) {
        $allExist = false;
        $missing[] = $relPath;
    }
}
assertCheck($allExist, "Slide 34 Folder Structure & File Manifest Compliance", $allExist ? "All " . count($expectedFiles) . " required files present!" : "Missing: " . implode(', ', $missing));

// 2. Audit Helper Functions - XSS Output Encoding (Slide 20)
$maliciousInput = "<script>alert('xss')</script>";
$escapedOutput = e($maliciousInput);
assertCheck($escapedOutput === "&lt;script&gt;alert(&#039;xss&#039;)&lt;/script&gt;", "Security: Output Encoding e() prevents XSS (Slide 20)", "Escaped output: {$escapedOutput}");

// 3. Audit Validation Helpers - Syntactic & Allowlist (Slide 16 & 21)
$posVal = validatePositiveInt("15");
$negVal = validatePositiveInt("-5");
$zeroVal = validatePositiveInt("0");
assertCheck($posVal === 15 && $negVal === false && $zeroVal === false, "Validation: Positive Integer Guard (> 0)", "15 -> 15 | -5 -> false | 0 -> false");

$validPrice = validateNonNegativeFloat("150000.50");
$invalidPrice = validateNonNegativeFloat("-100");
assertCheck($validPrice === 150000.50 && $invalidPrice === false, "Validation: Non-Negative Price Guard (>= 0)", "150000.50 -> valid | -100 -> false");

$allowedCol = validateSortColumn('price', ['name', 'price', 'stock']);
$blockedCol = validateSortColumn('users; DROP TABLE products', ['name', 'price', 'stock']);
assertCheck($allowedCol === 'price' && $blockedCol === 'id', "Security: Sorting Allowlist Column Guard (Slide 16 & 33)", "Allowed: 'price' | Malicious SQL input default fallback: 'id'");

// 4. Audit Business Rule 26 & 27: Transaction Commit & Rollback pattern in source code
$outPhpContent = file_get_contents(__DIR__ . '/../public/stock/out.php');
$hasBeginTrans = str_contains($outPhpContent, '$pdo->beginTransaction()');
$hasCommit = str_contains($outPhpContent, '$pdo->commit()');
$hasRollback = str_contains($outPhpContent, '$pdo->rollBack()');
$hasStockCheck = str_contains($outPhpContent, 'quantity > $currentStock') || str_contains($outPhpContent, '$validQty > $currentStock');

assertCheck($hasBeginTrans && $hasCommit && $hasRollback && $hasStockCheck, "Business Logic: Barang Keluar Transaction & Stock Check (Slide 26 & 33)", "beginTransaction, commit, rollBack, and stock <= 0 guard detected in public/stock/out.php");

// 5. Audit Slide 24 & 33: Role Authorization Check for User Administration
$usersIndexContent = file_get_contents(__DIR__ . '/../public/users/index.php');
$hasAdminGuard = str_contains($usersIndexContent, "requireRole('admin')");

$authPhpContent = file_get_contents(__DIR__ . '/../helpers/auth.php');
$has403 = str_contains($authPhpContent, "http_response_code(403)") && str_contains($authPhpContent, "Akses Ditolak");

assertCheck($hasAdminGuard && $has403, "Authorization: Staff User Administration Access Block (403 Forbidden) (Slide 24 & 33)", "requireRole('admin') & http_response_code(403) verified");

// 6. Audit Slide 28: Laporan Inventory Aggregate Query in dashboard.php
$dashContent = file_get_contents(__DIR__ . '/../public/dashboard.php');
$hasCaseIn = str_contains($dashContent, "WHEN sm.type='IN'");
$hasCaseOut = str_contains($dashContent, "WHEN sm.type='OUT'");
$hasGroupBy = str_contains($dashContent, "GROUP BY");

assertCheck($hasCaseIn && $hasCaseOut && $hasGroupBy, "Reporting: Inventory Aggregate Query (Slide 28 & 29)", "SUM(CASE WHEN sm.type='IN'...) & SUM(CASE WHEN sm.type='OUT'...) detected");

echo "\n=====================================================================\n";
echo "   FINAL RESULT: {$passCount} / {$totalCount} AUDIT CHECKS PASSED (" . round(($passCount / $totalCount) * 100) . "%)\n";
echo "=====================================================================\n";
