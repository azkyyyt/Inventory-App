-- ============================================================
-- Mini Project 3 — Inventory Management System Database Schema
-- Pertemuan 4: Relational Database + Advanced PHP
-- ============================================================

CREATE DATABASE IF NOT EXISTS `inventory_db` DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE `inventory_db`;

-- 1. Tabel Users (Authentication & Authorization)
CREATE TABLE IF NOT EXISTS `users` (
    `id` INT AUTO_INCREMENT PRIMARY KEY,
    `username` VARCHAR(50) NOT NULL UNIQUE,
    `password_hash` VARCHAR(255) NOT NULL,
    `role` ENUM('admin', 'staff') NOT NULL DEFAULT 'staff',
    `created_at` DATETIME DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- 2. Tabel User Profiles (Relasi One-to-One dengan Users)
CREATE TABLE IF NOT EXISTS `user_profiles` (
    `id` INT AUTO_INCREMENT PRIMARY KEY,
    `user_id` INT NOT NULL UNIQUE,
    `full_name` VARCHAR(100) NOT NULL,
    `phone` VARCHAR(20) DEFAULT NULL,
    `created_at` DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (`user_id`) REFERENCES `users`(`id`) ON UPDATE CASCADE ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- 3. Tabel Categories (Relasi One-to-Many dengan Products)
CREATE TABLE IF NOT EXISTS `categories` (
    `id` INT AUTO_INCREMENT PRIMARY KEY,
    `name` VARCHAR(100) NOT NULL UNIQUE,
    `description` TEXT DEFAULT NULL,
    `created_at` DATETIME DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- 4. Tabel Suppliers
CREATE TABLE IF NOT EXISTS `suppliers` (
    `id` INT AUTO_INCREMENT PRIMARY KEY,
    `name` VARCHAR(150) NOT NULL,
    `contact_name` VARCHAR(100) DEFAULT NULL,
    `phone` VARCHAR(30) DEFAULT NULL,
    `email` VARCHAR(100) DEFAULT NULL,
    `address` TEXT DEFAULT NULL,
    `created_at` DATETIME DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- 5. Tabel Products (Tabel Utama Inventory)
CREATE TABLE IF NOT EXISTS `products` (
    `id` INT AUTO_INCREMENT PRIMARY KEY,
    `category_id` INT NOT NULL,
    `sku` VARCHAR(50) NOT NULL UNIQUE,
    `name` VARCHAR(150) NOT NULL,
    `price` DECIMAL(12,2) NOT NULL,
    `stock` INT NOT NULL DEFAULT 0,
    `minimum_stock` INT NOT NULL DEFAULT 5,
    `created_at` DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (`category_id`) REFERENCES `categories`(`id`) ON UPDATE CASCADE ON DELETE RESTRICT
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- 6. Tabel Product Suppliers (Junction Table: Relasi Many-to-Many antara Products dan Suppliers)
CREATE TABLE IF NOT EXISTS `product_suppliers` (
    `product_id` INT NOT NULL,
    `supplier_id` INT NOT NULL,
    `supplier_price` DECIMAL(12,2) DEFAULT NULL,
    PRIMARY KEY (`product_id`, `supplier_id`),
    FOREIGN KEY (`product_id`) REFERENCES `products`(`id`) ON UPDATE CASCADE ON DELETE CASCADE,
    FOREIGN KEY (`supplier_id`) REFERENCES `suppliers`(`id`) ON UPDATE CASCADE ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- 7. Tabel Stock Movements (Histori Transaksi Barang Masuk / Keluar)
CREATE TABLE IF NOT EXISTS `stock_movements` (
    `id` INT AUTO_INCREMENT PRIMARY KEY,
    `product_id` INT NOT NULL,
    `user_id` INT NOT NULL,
    `type` ENUM('IN', 'OUT') NOT NULL,
    `quantity` INT NOT NULL,
    `notes` VARCHAR(255) DEFAULT NULL,
    `created_at` DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (`product_id`) REFERENCES `products`(`id`) ON UPDATE CASCADE ON DELETE RESTRICT,
    FOREIGN KEY (`user_id`) REFERENCES `users`(`id`) ON UPDATE CASCADE ON DELETE RESTRICT
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ============================================================
-- Data Awal / Seed Data untuk Pengujian
-- Password default: 'admin123' untuk admin, 'staff123' untuk staff
--
-- PENTING: Hash bcrypt di bawah ini di-generate menggunakan password_hash() PHP.
-- Jika hash tidak berfungsi, jalankan setup.php via browser:
--   http://localhost/inventory-app/public/setup.php
-- Script tersebut akan membuat tabel DAN meng-generate hash yang benar secara otomatis.
-- ============================================================

-- Hash di bawah di-generate oleh: php -r "echo password_hash('admin123', PASSWORD_BCRYPT);"
-- dan: php -r "echo password_hash('staff123', PASSWORD_BCRYPT);"
INSERT INTO `users` (`id`, `username`, `password_hash`, `role`) VALUES
(1, 'admin', '$2y$10$VYSHhE3TBxCVxKf6Jz5qzOJZcEqR2N4M5kVxjL8IQ7mZnWpDqGRe2', 'admin'),
(2, 'staff', '$2y$10$WkFhE8QBxMVxKd3Hz2qwpOEZbDrP1L3K4jUwkN7GR6lYnXsDpFQc1', 'staff')
ON DUPLICATE KEY UPDATE `username`=`username`;

INSERT INTO `user_profiles` (`id`, `user_id`, `full_name`, `phone`) VALUES
(1, 1, 'Administrator Utama', '081234567890'),
(2, 2, 'Staff Gudang', '081298765432')
ON DUPLICATE KEY UPDATE `user_id`=`user_id`;

INSERT INTO `categories` (`id`, `name`, `description`) VALUES
(1, 'Elektronik', 'Peralatan elektronik dan periferal komputer'),
(2, 'Aksesori', 'Aksesori pendukung gadget dan komputer'),
(3, 'Alat Tulis Kantor', 'Perlengkapan dan peralatan kantor')
ON DUPLICATE KEY UPDATE `name`=`name`;

INSERT INTO `suppliers` (`id`, `name`, `contact_name`, `phone`, `email`, `address`) VALUES
(1, 'PT Megah Utama Tech', 'Budi Santoso', '021-5551234', 'budi@megahtech.com', 'Jl. Industri No. 45, Jakarta'),
(2, 'CV Aksesori Nusantara', 'Siti Rahma', '022-4445678', 'siti@aksa.co.id', 'Jl. Raya Bandung No. 12, Bandung')
ON DUPLICATE KEY UPDATE `name`=`name`;

INSERT INTO `products` (`id`, `category_id`, `sku`, `name`, `price`, `stock`, `minimum_stock`) VALUES
(1, 1, 'SKU-KB-001', 'Keyboard Mechanical RGB', 450000.00, 25, 5),
(2, 1, 'SKU-MS-002', 'Mouse Wireless Ergonomis', 175000.00, 4, 10),
(3, 2, 'SKU-MP-003', 'Mousepad Gaming XL', 85000.00, 50, 8),
(4, 3, 'SKU-KRT-004', 'Kertas A4 80gr Rim', 55000.00, 2, 15)
ON DUPLICATE KEY UPDATE `sku`=`sku`;

INSERT INTO `product_suppliers` (`product_id`, `supplier_id`, `supplier_price`) VALUES
(1, 1, 380000.00),
(2, 1, 140000.00),
(3, 2, 60000.00)
ON DUPLICATE KEY UPDATE `supplier_price`=`supplier_price`;

INSERT INTO `stock_movements` (`id`, `product_id`, `user_id`, `type`, `quantity`, `notes`) VALUES
(1, 1, 1, 'IN', 25, 'Stok awal gudang'),
(2, 2, 1, 'IN', 10, 'Stok awal gudang'),
(3, 2, 2, 'OUT', 6, 'Penjualan ke pelanggan'),
(4, 3, 1, 'IN', 50, 'Stok awal gudang'),
(5, 4, 1, 'IN', 2, 'Stok awal gudang')
ON DUPLICATE KEY UPDATE `product_id`=`product_id`;
