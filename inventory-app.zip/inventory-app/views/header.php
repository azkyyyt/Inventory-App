<?php
// views/header.php
require_once __DIR__ . '/../helpers/auth.php';
require_once __DIR__ . '/../helpers/escape.php';

startSessionIfNeeded();
$user = currentUser();
$baseUrl = getBaseUrl();
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= isset($pageTitle) ? e($pageTitle) . ' - ' : '' ?>Inventory Management System</title>
    <!-- Bootstrap 5 CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- Font Awesome Icons -->
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" rel="stylesheet">
    <style>
        body { background-color: #f8f9fa; }
        .navbar-brand { font-weight: 700; letter-spacing: -0.5px; }
        .card-stat { border: none; border-radius: 10px; transition: transform 0.2s; }
        .card-stat:hover { transform: translateY(-3px); }
        .badge-role-admin { background-color: #dc3545; }
        .badge-role-staff { background-color: #0d6efd; }
    </style>
</head>
<body>

<nav class="navbar navbar-expand-lg navbar-dark bg-dark shadow-sm">
    <div class="container">
        <a class="navbar-brand" href="<?= $baseUrl ?>/dashboard.php">
            <i class="fa-solid fa-boxes-stacked me-2"></i>Inventory System
        </a>
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarNav">
            <?php if ($user): ?>
            <ul class="navbar-nav me-auto mb-2 mb-lg-0">
                <li class="nav-item">
                    <a class="nav-link <?= (str_contains($_SERVER['SCRIPT_NAME'], 'dashboard.php')) ? 'active' : '' ?>" href="<?= $baseUrl ?>/dashboard.php">
                        <i class="fa-solid fa-chart-line me-1"></i> Dashboard
                    </a>
                </li>
                <li class="nav-item">
                    <a class="nav-link <?= (str_contains($_SERVER['SCRIPT_NAME'], '/products/')) ? 'active' : '' ?>" href="<?= $baseUrl ?>/products/index.php">
                        <i class="fa-solid fa-box me-1"></i> Produk
                    </a>
                </li>
                <li class="nav-item">
                    <a class="nav-link <?= (str_contains($_SERVER['SCRIPT_NAME'], '/categories/')) ? 'active' : '' ?>" href="<?= $baseUrl ?>/categories/index.php">
                        <i class="fa-solid fa-tags me-1"></i> Kategori
                    </a>
                </li>
                <li class="nav-item">
                    <a class="nav-link <?= (str_contains($_SERVER['SCRIPT_NAME'], '/suppliers/')) ? 'active' : '' ?>" href="<?= $baseUrl ?>/suppliers/index.php">
                        <i class="fa-solid fa-truck-field me-1"></i> Supplier
                    </a>
                </li>
                <li class="nav-item dropdown">
                    <a class="nav-link dropdown-toggle <?= (str_contains($_SERVER['SCRIPT_NAME'], '/stock/')) ? 'active' : '' ?>" href="#" id="stockDropdown" role="button" data-bs-toggle="dropdown">
                        <i class="fa-solid fa-arrow-right-arrow-left me-1"></i> Transaksi
                    </a>
                    <ul class="dropdown-menu">
                        <li><a class="dropdown-item" href="<?= $baseUrl ?>/stock/in.php"><i class="fa-solid fa-arrow-down text-success me-2"></i>Barang Masuk</a></li>
                        <li><a class="dropdown-item" href="<?= $baseUrl ?>/stock/out.php"><i class="fa-solid fa-arrow-up text-danger me-2"></i>Barang Keluar</a></li>
                        <li><hr class="dropdown-divider"></li>
                        <li><a class="dropdown-item" href="<?= $baseUrl ?>/stock/history.php"><i class="fa-solid fa-clock-rotate-left me-2"></i>Histori Transaksi</a></li>
                    </ul>
                </li>
                <?php if ($user['role'] === 'admin'): ?>
                <li class="nav-item">
                    <a class="nav-link <?= (str_contains($_SERVER['SCRIPT_NAME'], '/users/')) ? 'active' : '' ?>" href="<?= $baseUrl ?>/users/index.php">
                        <i class="fa-solid fa-users-gear me-1"></i> Pengguna
                    </a>
                </li>
                <?php endif; ?>
            </ul>
            <div class="d-flex align-items-center text-white gap-3">
                <span class="small">
                    <i class="fa-solid fa-circle-user me-1"></i> <?= e($user['full_name'] ?? $user['username']) ?>
                    <span class="badge <?= $user['role'] === 'admin' ? 'badge-role-admin' : 'badge-role-staff' ?> ms-1">
                        <?= strtoupper(e($user['role'])) ?>
                    </span>
                </span>
                <a href="<?= $baseUrl ?>/logout.php" class="btn btn-outline-light btn-sm">
                    <i class="fa-solid fa-right-from-bracket me-1"></i> Logout
                </a>
            </div>
            <?php endif; ?>
        </div>
    </div>
</nav>

<div class="container my-4">
<?php if (isset($_SESSION['flash_success'])): ?>
    <div class="alert alert-success alert-dismissible fade show shadow-sm" role="alert">
        <i class="fa-solid fa-circle-check me-2"></i><?= e($_SESSION['flash_success']) ?>
        <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
    </div>
    <?php unset($_SESSION['flash_success']); ?>
<?php endif; ?>

<?php if (isset($_SESSION['flash_error'])): ?>
    <div class="alert alert-danger alert-dismissible fade show shadow-sm" role="alert">
        <i class="fa-solid fa-triangle-exclamation me-2"></i><?= e($_SESSION['flash_error']) ?>
        <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
    </div>
    <?php unset($_SESSION['flash_error']); ?>
<?php endif; ?>
