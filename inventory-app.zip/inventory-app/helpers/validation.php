<?php
// helpers/validation.php
// Menangani Server-Side Input Validation (Slide 21 & 33)

/**
 * Validasi integer positif (> 0)
 */
function validatePositiveInt($val, string $fieldName = 'Nilai'): int|false {
    $intVal = filter_var($val, FILTER_VALIDATE_INT);
    if ($intVal === false || $intVal <= 0) {
        return false;
    }
    return $intVal;
}

/**
 * Validasi integer non-negatif (>= 0)
 */
function validateNonNegativeInt($val, string $fieldName = 'Nilai'): int|false {
    $intVal = filter_var($val, FILTER_VALIDATE_INT);
    if ($intVal === false || $intVal < 0) {
        return false;
    }
    return $intVal;
}

/**
 * Validasi harga / decimal non-negatif (>= 0)
 */
function validateNonNegativeFloat($val): float|false {
    if (!is_numeric($val)) {
        return false;
    }
    $floatVal = (float) $val;
    if ($floatVal < 0) {
        return false;
    }
    return $floatVal;
}

/**
 * Validasi SKU Unik (Slide 33: SKU harus unik)
 */
function isSkuUnique(PDO $pdo, string $sku, ?int $excludeProductId = null): bool {
    if ($excludeProductId !== null) {
        $stmt = $pdo->prepare("SELECT COUNT(*) FROM products WHERE sku = :sku AND id != :id");
        $stmt->execute(['sku' => $sku, 'id' => $excludeProductId]);
    } else {
        $stmt = $pdo->prepare("SELECT COUNT(*) FROM products WHERE sku = :sku");
        $stmt->execute(['sku' => $sku]);
    }
    return (int) $stmt->fetchColumn() === 0;
}

/**
 * Validasi Kolom Sorting (Slide 16 & 33: Kolom sorting harus dipilih dari allowlist)
 */
function validateSortColumn(string $column, array $allowlist, string $default = 'id'): string {
    return in_array($column, $allowlist, true) ? $column : $default;
}

/**
 * Validasi Arah Sorting (ASC / DESC)
 */
function validateSortDirection(string $direction, string $default = 'ASC'): string {
    $dir = strtoupper($direction);
    return in_array($dir, ['ASC', 'DESC'], true) ? $dir : $default;
}
