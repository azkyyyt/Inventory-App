<?php
// public/users/create.php
require_once __DIR__ . '/../../config/database.php';
require_once __DIR__ . '/../../helpers/auth.php';
require_once __DIR__ . '/../../helpers/escape.php';

requireRole('admin');
$pdo = getPDO();

$errors = [];
$username = '';
$fullName = '';
$phone = '';
$role = 'staff';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = trim($_POST['username'] ?? '');
    $password = $_POST['password'] ?? '';
    $fullName = trim($_POST['full_name'] ?? '');
    $phone = trim($_POST['phone'] ?? '');
    $role = $_POST['role'] ?? 'staff';

    if (empty($username)) {
        $errors[] = 'Username wajib diisi.';
    } else {
        $stmtCheck = $pdo->prepare("SELECT COUNT(*) FROM users WHERE username = :username");
        $stmtCheck->execute(['username' => $username]);
        if ((int)$stmtCheck->fetchColumn() > 0) {
            $errors[] = 'Username "' . htmlspecialchars($username) . '" sudah digunakan.';
        }
    }

    if (empty($password) || strlen($password) < 6) {
        $errors[] = 'Password wajib diisi minimal 6 karakter.';
    }

    if (empty($fullName)) {
        $errors[] = 'Nama lengkap wajib diisi.';
    }

    if (!in_array($role, ['admin', 'staff'], true)) {
        $errors[] = 'Role tidak valid.';
    }

    if (empty($errors)) {
        $pdo->beginTransaction();
        try {
            // Hash password (Slide 23)
            $passwordHash = password_hash($password, PASSWORD_DEFAULT);

            $stmtUser = $pdo->prepare("INSERT INTO users (username, password_hash, role) VALUES (:username, :hash, :role)");
            $stmtUser->execute([
                'username' => $username,
                'hash' => $passwordHash,
                'role' => $role
            ]);
            $userId = (int) $pdo->lastInsertId();

            // Insert One-to-One user_profiles (Slide 6)
            $stmtProfile = $pdo->prepare("INSERT INTO user_profiles (user_id, full_name, phone) VALUES (:user_id, :full_name, :phone)");
            $stmtProfile->execute([
                'user_id' => $userId,
                'full_name' => $fullName,
                'phone' => $phone
            ]);

            $pdo->commit();
            $_SESSION['flash_success'] = 'Pengguna "' . $username . '" berhasil dibuat.';
            header("Location: index.php");
            exit;
        } catch (Throwable $e) {
            $pdo->rollBack();
            $errors[] = 'Gagal membuat pengguna: ' . $e->getMessage();
        }
    }
}

$pageTitle = 'Tambah User Baru';
include __DIR__ . '/../../views/header.php';
?>

<div class="row justify-content-center">
    <div class="col-md-8 col-lg-6">
        <div class="card shadow-sm border-0">
            <div class="card-header bg-primary text-white py-3">
                <h5 class="mb-0 fw-bold"><i class="fa-solid fa-user-plus me-2"></i>Tambah User Baru</h5>
            </div>
            <div class="card-body p-4">
                <?php if (!empty($errors)): ?>
                    <div class="alert alert-danger shadow-sm">
                        <ul class="mb-0 ps-3">
                            <?php foreach ($errors as $err): ?>
                                <li><?= e($err) ?></li>
                            <?php endforeach; ?>
                        </ul>
                    </div>
                <?php endif; ?>

                <form method="POST" action="create.php">
                    <div class="mb-3">
                        <label for="username" class="form-label fw-semibold">Username <span class="text-danger">*</span></label>
                        <input type="text" class="form-control" id="username" name="username" value="<?= e($username) ?>" required placeholder="Contoh: staff_gudang2">
                    </div>

                    <div class="mb-3">
                        <label for="password" class="form-label fw-semibold">Password <span class="text-danger">*</span></label>
                        <input type="password" class="form-control" id="password" name="password" required placeholder="Minimal 6 karakter">
                    </div>

                    <div class="mb-3">
                        <label for="full_name" class="form-label fw-semibold">Nama Lengkap (Profile) <span class="text-danger">*</span></label>
                        <input type="text" class="form-control" id="full_name" name="full_name" value="<?= e($fullName) ?>" required placeholder="Contoh: Ahmad Subagyo">
                    </div>

                    <div class="mb-3">
                        <label for="phone" class="form-label fw-semibold">No. Telepon</label>
                        <input type="text" class="form-control" id="phone" name="phone" value="<?= e($phone) ?>" placeholder="Contoh: 08123456789">
                    </div>

                    <div class="mb-3">
                        <label for="role" class="form-label fw-semibold">Role / Hak Akses <span class="text-danger">*</span></label>
                        <select class="form-select" id="role" name="role" required>
                            <option value="staff" <?= ($role === 'staff') ? 'selected' : '' ?>>Staff (Melihat Produk &amp; Transaksi)</option>
                            <option value="admin" <?= ($role === 'admin') ? 'selected' : '' ?>>Admin (Akses Penuh Seluruh Sistem)</option>
                        </select>
                    </div>

                    <div class="d-flex justify-content-between align-items-center mt-4 pt-3 border-top">
                        <a href="index.php" class="btn btn-outline-secondary"><i class="fa-solid fa-arrow-left me-1"></i> Batal</a>
                        <button type="submit" class="btn btn-primary fw-bold"><i class="fa-solid fa-floppy-disk me-1"></i> Simpan User</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>

<?php include __DIR__ . '/../../views/footer.php'; ?>
