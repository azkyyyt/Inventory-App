<?php
// public/categories/delete.php
require_once __DIR__ . '/../../config/database.php';
require_once __DIR__ . '/../../helpers/auth.php';

requireRole('admin');
$pdo = getPDO();

$id = filter_input(INPUT_GET, 'id', FILTER_VALIDATE_INT);
if (!$id) {
    header("Location: index.php");
    exit;
}

$stmt = $pdo->prepare("SELECT name FROM categories WHERE id = :id");
$stmt->execute(['id' => $id]);
$category = $stmt->fetch();

if (!$category) {
    $_SESSION['flash_error'] = 'Kategori tidak ditemukan.';
    header("Location: index.php");
    exit;
}

// Check child products (ON DELETE RESTRICT constraint)
$stmtProd = $pdo->prepare("SELECT COUNT(*) FROM products WHERE category_id = :id");
$stmtProd->execute(['id' => $id]);
$productCount = (int) $stmtProd->fetchColumn();

if ($productCount > 0) {
    $_SESSION['flash_error'] = 'Gagal menghapus kategori "' . $category['name'] . '". Kategori ini masih digunakan oleh ' . $productCount . ' produk (Referential Integrity RESTRICT).';
    header("Location: index.php");
    exit;
}

try {
    $stmtDelete = $pdo->prepare("DELETE FROM categories WHERE id = :id");
    $stmtDelete->execute(['id' => $id]);
    $_SESSION['flash_success'] = 'Kategori "' . $category['name'] . '" berhasil dihapus.';
} catch (PDOException $e) {
    $_SESSION['flash_error'] = 'Gagal menghapus kategori: ' . $e->getMessage();
}

header("Location: index.php");
exit;
