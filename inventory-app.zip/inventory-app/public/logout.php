<?php
// public/logout.php
require_once __DIR__ . '/../helpers/auth.php';

logoutUser();
header("Location: login.php");
exit;
